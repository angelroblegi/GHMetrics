import pandas as pd

# Rutas de los archivos
archivo_destino = "Febrero.xlsx"   # Este se modifica
archivo_fuente = "celulas.xlsx"              # Tiene la columna Celula

# Cargar los archivos Excel
destino = pd.read_excel(archivo_destino)
fuente = pd.read_excel(archivo_fuente)

# Asegurar que la columna Celula exista en destino
if "Celula" not in destino.columns:
    destino["Celula"] = None

# Hacer merge solo para obtener la columna Celula desde fuente
merge = destino.merge(
    fuente[["NombreProyecto", "Celula"]], 
    on="NombreProyecto",
    how="left",
    suffixes=("", "_src")  # Celula_src viene del archivo fuente
)

# Si Celula en destino está vacía, rellenar con la Celula del archivo fuente
merge["Celula"] = merge["Celula"].fillna(merge["Celula_src"])

# Eliminar la columna temporal
merge = merge.drop(columns=["Celula_src"])

# Guardar sobrescribiendo el archivo existente
merge.to_excel(archivo_destino, index=False)

print("Archivo actualizado correctamente.")
