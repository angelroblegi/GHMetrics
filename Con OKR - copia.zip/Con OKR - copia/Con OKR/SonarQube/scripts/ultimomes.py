import requests
import pandas as pd
from datetime import datetime
import time
import os

# Token y URLs base
TOKEN = 'squ_9d4bf55717f19e3c05a873b1f350b96c07a636a1'
BASE_URL = 'http://hiroshima04s:9000'
COMPONENTS_URL = f'{BASE_URL}/api/components/search'
MEASURES_URL = f'{BASE_URL}/api/measures/component'
PROJECT_ANALYSES_URL = f'{BASE_URL}/api/project_analyses/search'


def obtener_todos_los_proyectos():
    """Obtiene todos los proyectos disponibles en SonarQube"""
    proyectos = []
    page = 1
    page_size = 500
    
    print("🔍 Obteniendo proyectos desde SonarQube...")
    
    while True:
        params = {'qualifiers': 'TRK', 'p': page, 'ps': page_size}
        try:
            response = requests.get(COMPONENTS_URL, params=params, auth=(TOKEN, ''))
            if response.status_code != 200:
                print(f"❌ Error en página {page}: {response.status_code}")
                break
            
            data = response.json()
            componentes = data.get('components', [])
            if not componentes:
                break
            
            proyectos.extend(componentes)
            
            # Verificar si hay más páginas
            paging = data.get('paging', {})
            total = paging.get('total', 0)
            print(f"📄 Página {page}: {len(componentes)} proyectos (Total acumulado: {len(proyectos)}/{total})")
            
            if len(proyectos) >= total:
                break
            
            page += 1
            time.sleep(0.1)  # Pausa pequeña para no sobrecargar
            
        except Exception as e:
            print(f"❌ Error obteniendo proyectos: {e}")
            break
    
    return proyectos


def obtener_fecha_ultima_ejecucion(proyecto_key):
    """Obtiene la fecha de la última ejecución del proyecto"""
    # Intentar primero con project_analyses (más preciso)
    try:
        params = {'project': proyecto_key, 'ps': 1}
        response = requests.get(PROJECT_ANALYSES_URL, params=params, auth=(TOKEN, ''))
        if response.status_code == 200:
            data = response.json()
            analyses = data.get('analyses', [])
            if analyses:
                return analyses[0].get('date')
    except Exception:
        pass
    
    # Si no funciona, usar measures
    try:
        params = {'component': proyecto_key, 'metricKeys': 'lines'}
        response = requests.get(MEASURES_URL, params=params, auth=(TOKEN, ''))
        if response.status_code == 200:
            data = response.json()
            component = data.get('component', {})
            return component.get('analysisDate')
    except Exception:
        pass
    
    return None


def formatear_fecha(fecha_str):
    """Convierte la fecha de SonarQube a un formato legible"""
    if not fecha_str:
        return 'Sin análisis'
    
    try:
        # Limpiar timezone si existe
        if '+' in fecha_str:
            fecha_str = fecha_str.split('+')[0]
        elif fecha_str.endswith('Z'):
            fecha_str = fecha_str.replace('Z', '')
        elif '-' in fecha_str[-6:]:
            fecha_str = fecha_str.rsplit('-', 1)[0]
        
        # Convertir a datetime y formatear
        fecha_obj = datetime.strptime(fecha_str, '%Y-%m-%dT%H:%M:%S')
        return fecha_obj.strftime('%Y-%m-%d %H:%M:%S')
    except Exception:
        return fecha_str  # Devolver tal como está si no se puede parsear


def procesar_proyectos(proyectos):
    """Procesa todos los proyectos para obtener su última ejecución"""
    resultados = []
    total = len(proyectos)
    
    print(f"\n📊 Procesando {total} proyectos...")
    print("=" * 50)
    
    for i, proyecto in enumerate(proyectos, 1):
        proyecto_key = proyecto['key']
        proyecto_name = proyecto.get('name', proyecto_key)
        
        # Mostrar progreso
        if i % 25 == 0 or i == 1:
            print(f"⏳ Procesando {i}/{total}: {proyecto_name}")
        
        # Obtener fecha de última ejecución
        fecha_raw = obtener_fecha_ultima_ejecucion(proyecto_key)
        fecha_formateada = formatear_fecha(fecha_raw)
        
        resultado = {
            'Clave': proyecto_key,
            'Nombre': proyecto_name,
            'Última Ejecución': fecha_formateada
        }
        
        resultados.append(resultado)
        time.sleep(0.05)  # Pausa para no sobrecargar el servidor
    
    return resultados


def guardar_excel(resultados, nombre='proyectos_sonarqube_mes_Mayo.xlsx'):
    """Guarda los resultados en Excel"""
    if not resultados:
        print("❌ No hay proyectos para guardar")
        return
    
    # Crear DataFrame y ordenar
    df = pd.DataFrame(resultados)
    
    # Separar proyectos con y sin análisis
    con_analisis = df[df['Última Ejecución'] != 'Sin análisis'].copy()
    sin_analisis = df[df['Última Ejecución'] == 'Sin análisis'].copy()
    
    # Ordenar los que tienen análisis por fecha (más recientes primero)
    if not con_analisis.empty:
        con_analisis['fecha_sort'] = pd.to_datetime(con_analisis['Última Ejecución'], errors='coerce')
        con_analisis = con_analisis.sort_values('fecha_sort', ascending=False)
        con_analisis = con_analisis.drop('fecha_sort', axis=1)
    
    # Combinar: primero con análisis, luego sin análisis
    df_final = pd.concat([con_analisis, sin_analisis], ignore_index=True)
    
    # Guardar en Excel
    ruta = os.path.abspath(nombre)
    fecha_consulta = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    
    with pd.ExcelWriter(ruta, engine='openpyxl') as writer:
        # Hoja principal
        df_final.to_excel(writer, sheet_name='Proyectos', index=False)
        
        # Hoja de resumen
        total_proyectos = len(resultados)
        con_ejecucion = len([r for r in resultados if r['Última Ejecución'] != 'Sin análisis'])
        sin_ejecucion = total_proyectos - con_ejecucion
        
        resumen = {
            'Estadística': [
                'Total de proyectos',
                'Proyectos con análisis',
                'Proyectos sin análisis',
                'Servidor SonarQube',
                'Fecha de consulta'
            ],
            'Valor': [
                total_proyectos,
                con_ejecucion,
                sin_ejecucion,
                BASE_URL,
                fecha_consulta
            ]
        }
        pd.DataFrame(resumen).to_excel(writer, sheet_name='Resumen', index=False)
    
    print(f"\n✅ Archivo guardado: {ruta}")
    print(f"📊 Total proyectos: {total_proyectos}")
    print(f"   • Con análisis: {con_ejecucion}")
    print(f"   • Sin análisis: {sin_ejecucion}")


def main():
    print("🚀 CONSULTA DE TODOS LOS PROYECTOS - SONARQUBE")
    print("=" * 50)
    print(f"🌐 Servidor: {BASE_URL}")
    
    # Obtener todos los proyectos
    proyectos = obtener_todos_los_proyectos()
    if not proyectos:
        print("❌ No se encontraron proyectos")
        return
    
    print(f"✅ Total proyectos encontrados: {len(proyectos)}")
    
    # Procesar proyectos
    resultados = procesar_proyectos(proyectos)
    
    # Guardar en Excel
    guardar_excel(resultados)
    
    print("\n🎉 ¡Proceso completado!")


if __name__ == '__main__':
    main()