import requests
import json

# URL del endpoint
url = "https://preproduccionmicroservicios.aportesenlinea.com/Mareigua.Fanaia.ControlAcceso.Servicio/api/ControlAcceso/ConsultarAccesoUsuario"

# --- Si el endpoint requiere cabeceras (por ejemplo autenticación o tipo de contenido) ---
headers = {
    "Content-Type": "application/json",
    # "Authorization": "Bearer TU_TOKEN_AQUI"  # <- si se requiere token
}

# --- Datos a enviar en la solicitud (ajústalos según la API) ---
payload = {
    "Usuario": "prueba123",   # ejemplo de campo
    "Clave": "123456"         # ejemplo de campo
}

try:
    # Cambia a requests.get(url, ...) si el endpoint es GET
    response = requests.post(url, headers=headers, json=payload, timeout=15)

    print(f"✅ Código de estado: {response.status_code}")

    # Mostrar respuesta formateada
    try:
        data = response.json()
        print("📦 Respuesta JSON:")
        print(json.dumps(data, indent=4, ensure_ascii=False))
    except ValueError:
        print("⚠️ La respuesta no es JSON:")
        print(response.text)

except requests.exceptions.RequestException as e:
    print("❌ Error en la conexión o la solicitud:")
    print(e)
