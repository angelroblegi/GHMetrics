"""
sonarqube_sonarlint_status.py
-------------------------------
Consulta todos los usuarios activos de SonarQube y reporta si han
vinculado SonarLint / SonarQube for IDE (Connected Mode).

Requiere:
  - Token de administrador del sistema (Administer System)
  - Python 3.8+
  - pip install requests python-dotenv tabulate  (tabulate es opcional)

Uso:
  python sonarqube_sonarlint_status.py

Variables de entorno (o editar directamente en CONFIG):
  SONAR_URL   -> URL base de SonarQube, ej: https://sonar.miempresa.com
  SONAR_TOKEN -> Token de administrador
"""

import os
import sys
from datetime import datetime, timezone

try:
    import requests
except ImportError:
    sys.exit("❌  Instala requests:  pip install requests")

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass  # python-dotenv es opcional

# ─────────────────────────────────────────────
#  CONFIG  (sobreescrito por variables de entorno)
# ─────────────────────────────────────────────
SONAR_URL   = os.getenv("SONAR_URL",   "http://hiroshima04s:9000")
SONAR_TOKEN = os.getenv("SONAR_TOKEN", "squ_9d4bf55717f19e3c05a873b1f350b96c07a636a1")

# Días de inactividad para considerar conexión IDE como "antigua"
DIAS_ALERTA = 30
# ─────────────────────────────────────────────


def get_all_users(base_url: str, token: str) -> list[dict]:
    """Pagina /api/users/search y retorna todos los usuarios activos."""
    url = f"{base_url.rstrip('/')}/api/users/search"
    headers = {"Authorization": f"Bearer {token}"}
    usuarios = []
    page = 1
    page_size = 500

    while True:
        params = {"active": "true", "ps": page_size, "p": page}
        resp = requests.get(url, headers=headers, params=params, timeout=15)

        if resp.status_code == 401:
            sys.exit("❌  Token inválido o sin permiso. Se requiere 'Administer System'.")
        if resp.status_code != 200:
            sys.exit(f"❌  Error {resp.status_code} al consultar SonarQube: {resp.text}")

        data = resp.json()
        usuarios.extend(data.get("users", []))

        paging = data.get("paging", {})
        total = paging.get("total", 0)
        if len(usuarios) >= total:
            break
        page += 1

    return usuarios


def clasificar(usuario: dict, dias_alerta: int) -> dict:
    """Determina el estado de conexión IDE de un usuario."""
    login       = usuario.get("login", "")
    nombre      = usuario.get("name", "")
    email       = usuario.get("email", "")
    ide_fecha   = usuario.get("sonarLintLastConnectionDate")  # campo clave
    last_login  = usuario.get("lastConnectionDate")

    ahora = datetime.now(timezone.utc)

    if ide_fecha:
        # Parsear ISO 8601 (SonarQube retorna algo como "2024-03-15T10:30:00+0000")
        try:
            dt_ide = datetime.fromisoformat(ide_fecha.replace("+0000", "+00:00"))
        except ValueError:
            dt_ide = None

        if dt_ide:
            dias_desde = (ahora - dt_ide).days
            if dias_desde <= dias_alerta:
                estado = "✅ Activo con IDE"
            else:
                estado = f"⚠️  IDE vinculado pero sin uso ({dias_desde}d atrás)"
            ultima_ide = dt_ide.strftime("%Y-%m-%d")
        else:
            estado = "⚠️  IDE vinculado (fecha inválida)"
            ultima_ide = ide_fecha
    else:
        estado    = "❌ Sin IDE vinculado"
        ultima_ide = "—"

    return {
        "Login":          login,
        "Nombre":         nombre,
        "Email":          email,
        "Estado IDE":     estado,
        "Última conexión IDE": ultima_ide,
        "Último acceso SQ":   last_login[:10] if last_login else "—",
    }


def imprimir_tabla(filas: list[dict]) -> None:
    """Imprime la tabla formateada. Usa tabulate si está disponible."""
    try:
        from tabulate import tabulate
        print(tabulate(filas, headers="keys", tablefmt="rounded_outline"))
    except ImportError:
        # Fallback: tabla manual
        if not filas:
            return
        cols = list(filas[0].keys())
        anchos = {c: max(len(c), max(len(str(f[c])) for f in filas)) for c in cols}

        sep  = "  ".join("-" * anchos[c] for c in cols)
        head = "  ".join(c.ljust(anchos[c]) for c in cols)
        print(head)
        print(sep)
        for f in filas:
            print("  ".join(str(f[c]).ljust(anchos[c]) for c in cols))


def resumen(filas: list[dict]) -> None:
    activos    = sum(1 for f in filas if f["Estado IDE"].startswith("✅"))
    antiguos   = sum(1 for f in filas if f["Estado IDE"].startswith("⚠️"))
    sin_ide    = sum(1 for f in filas if f["Estado IDE"].startswith("❌"))
    total      = len(filas)

    print(f"\n{'─'*55}")
    print(f"  Total usuarios activos : {total}")
    print(f"  ✅ Con IDE activo       : {activos}  ({activos/total*100:.1f}%)")
    print(f"  ⚠️  IDE antiguo (>{DIAS_ALERTA}d)   : {antiguos}  ({antiguos/total*100:.1f}%)")
    print(f"  ❌ Sin IDE vinculado    : {sin_ide}  ({sin_ide/total*100:.1f}%)")
    print(f"{'─'*55}\n")


def exportar_csv(filas: list[dict], archivo: str = "reporte_sonarlint.csv") -> None:
    import csv
    if not filas:
        return
    with open(archivo, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=filas[0].keys())
        writer.writeheader()
        writer.writerows(filas)
    print(f"📄 Reporte exportado: {archivo}")


def main():
    print(f"\n🔍 Consultando usuarios en: {SONAR_URL}")
    print(f"   Umbral de actividad IDE:  {DIAS_ALERTA} días\n")

    usuarios = get_all_users(SONAR_URL, SONAR_TOKEN)

    if not usuarios:
        print("⚠️  No se encontraron usuarios activos.")
        return

    filas = [clasificar(u, DIAS_ALERTA) for u in usuarios]

    # Ordenar: primero sin IDE, luego IDE antiguo, luego activos
    orden = {"❌": 0, "⚠️": 1, "✅": 2}
    filas.sort(key=lambda f: orden.get(f["Estado IDE"][0], 9))

    imprimir_tabla(filas)
    resumen(filas)

    # Descomenta si quieres exportar CSV automáticamente:
    # exportar_csv(filas)

    # Filtro: solo los SIN IDE
    sin_ide = [f for f in filas if f["Estado IDE"].startswith("❌")]
    if sin_ide:
        print(f"🚨 Usuarios SIN SonarLint / SonarQube IDE vinculado ({len(sin_ide)}):")
        for u in sin_ide:
            print(f"   • {u['Login']:20} {u['Nombre']:30} {u['Email']}")
    else:
        print("🎉 ¡Todos los usuarios tienen SonarQube IDE vinculado!")


if __name__ == "__main__":
    main()