import requests
import pandas as pd
import time
from datetime import datetime

# Token y URLs base
TOKEN = 'squ_9d4bf55717f19e3c05a873b1f350b96c07a636a1'
BASE_COMPONENTS_URL = 'http://hiroshima04s:9000/api/components/search'
BASE_MEASURES_URL = 'http://hiroshima04s:9000/api/measures/component'
BASE_ISSUES_URL = 'http://hiroshima04s:9000/api/issues/search'
METRICS = 'security_rating,reliability_rating,coverage,sqale_rating,duplicated_lines_density'

# Mapa de ratings
rating_map = {
    '1.0': 'A',
    '2.0': 'B',
    '3.0': 'C',
    '4.0': 'D',
    '5.0': 'E'
}

def calcular_rating_duplicacion(valor):
    """
    Calcula el rating de duplicación basado en el porcentaje
    0-3: A, 3-5: B, 5-10: C, 10-20: D, >20: E
    """
    try:
        valor_float = float(valor)
        if valor_float < 3:
            return 'A'
        elif valor_float < 5:
            return 'B'
        elif valor_float < 10:
            return 'C'
        elif valor_float < 20:
            return 'D'
        else:
            return 'E'
    except (ValueError, TypeError):
        return ''

# Obtener proyectos SonarQube
def obtener_proyectos():
    proyectos = []
    page = 1
    while True:
        params = {'qualifiers': 'TRK', 'ps': 500, 'p': page}
        response = requests.get(BASE_COMPONENTS_URL, params=params, auth=(TOKEN, ''))
        if response.status_code == 200:
            data = response.json()
            proyectos.extend([comp['name'] for comp in data['components']])
            if data['paging']['total'] > page * 500:
                page += 1
            else:
                break
        else:
            print(f"Error al obtener proyectos: {response.status_code}")
            break
    return proyectos

# Obtener métricas por proyecto
def obtener_metricas(proyectos):
    resultados = []
    for nombre in proyectos:
        print(f"Consultando: {nombre}")
        params_measures = {'component': nombre, 'metricKeys': METRICS}
        try:
            response = requests.get(BASE_MEASURES_URL, params=params_measures, auth=(TOKEN, ''))
            if response.status_code == 200:
                data = response.json()
                measures = {m['metric']: m['value'] for m in data['component']['measures']}

                security = rating_map.get(measures.get('security_rating', ''), '')
                reliability = rating_map.get(measures.get('reliability_rating', ''), '')
                maintainability = rating_map.get(measures.get('sqale_rating', ''), '')
                
                # Calcular rating de duplicación
                duplicated_value = measures.get('duplicated_lines_density', '')
                duplicated_rating = calcular_rating_duplicacion(duplicated_value) if duplicated_value else ''

                params_issues = {
                    'componentKeys': nombre,
                    'types': 'BUG',
                    'resolved': 'false',
                    'facets': 'severities',
                    'ps': 1
                }

                bug_response = requests.get(BASE_ISSUES_URL, params=params_issues, auth=(TOKEN, ''))
                severities = {'BLOCKER': 0, 'CRITICAL': 0, 'MAJOR': 0, 'MINOR': 0, 'INFO': 0}
                total_bugs = 0

                if bug_response.status_code == 200:
                    bug_data = bug_response.json()
                    total_bugs = bug_data.get('total', 0)
                    for facet in bug_data.get('facets', []):
                        if facet['property'] == 'severities':
                            for val in facet['values']:
                                severity = val['val']
                                if severity in severities:
                                    severities[severity] = val['count']

                resultados.append({
                    'NombreProyecto': nombre,
                    'security_rating': security,
                    'reliability_rating': reliability,
                    'sqale_rating': maintainability,
                    'coverage': measures.get('coverage', ''),
                    'duplicated_lines_density': duplicated_rating,
                    'bugs': total_bugs,
                    'bugs_blocker': severities['BLOCKER'],
                    'bugs_critical': severities['CRITICAL'],
                    'bugs_major': severities['MAJOR'],
                    'bugs_minor': severities['MINOR'],
                    'bugs_info': severities['INFO']
                })

            else:
                print(f"Error en métricas {nombre}: {response.status_code}")
        except Exception as e:
            print(f"Excepción {nombre}: {e}")
        time.sleep(0.5)
    return pd.DataFrame(resultados)

# Combinar con célula y duplicar proyectos de Beyond
def combinar_con_celulas(df_metricas):
    try:
        # Solicitar nombre del archivo
        print("\n" + "="*60)
        print("Por favor ingrese el nombre del archivo Excel con las células")
        print("(Debe tener las columnas: NombreProyecto y Celula)")
        nombre_archivo_celulas = input("Nombre del archivo (ejemplo: Inventario_actual.xlsx): ").strip()
        
        if not nombre_archivo_celulas:
            nombre_archivo_celulas = 'Inventario_actual.xlsx'
            print(f"Usando archivo por defecto: {nombre_archivo_celulas}")
        
        df_celulas = pd.read_excel(nombre_archivo_celulas)
        print(f"✓ Archivo '{nombre_archivo_celulas}' cargado correctamente")
        print(f"  Columnas encontradas: {df_celulas.columns.tolist()}")
        
        # Detectar columnas
        col_proyecto = None
        col_celula = None
        
        for col in df_celulas.columns:
            if 'nombre' in col.lower() and 'proyecto' in col.lower():
                col_proyecto = col
                break
        
        if col_proyecto is None:
            for col in df_celulas.columns:
                if col in ['NombreProyecto', 'Nombre Proyecto', 'Proyecto', 'proyecto', 'Project']:
                    col_proyecto = col
                    break
        
        for col in df_celulas.columns:
            if 'celula' in col.lower() or 'célula' in col.lower():
                col_celula = col
                break
        
        if col_proyecto is None or col_celula is None:
            print(f"⚠️ ERROR: No se pudieron identificar las columnas necesarias")
            print(f"  Columna proyecto: {col_proyecto}")
            print(f"  Columna célula: {col_celula}")
            print("  Guardando sin asignación de células...")
            df_metricas['Celula'] = ''
            df_final = df_metricas
        else:
            print(f"✓ Usando columnas: '{col_proyecto}' y '{col_celula}'")
            
            # Renombrar columnas para estandarizar
            df_celulas = df_celulas.rename(columns={col_proyecto: 'NombreProyecto', col_celula: 'Celula'})
            
            df_merge = pd.merge(df_metricas, df_celulas[['NombreProyecto', 'Celula']], 
                               on='NombreProyecto', how='left')

            # Renombrar células específicas
            df_merge['Celula'] = df_merge['Celula'].replace({
                'GroundBreaker': 'Mindshift', 
                'Omoikane': 'Mindshift'
            })

            # Separar proyectos Beyond
            df_beyond = df_merge[df_merge['Celula'] == 'Beyond'].copy()
            df_otros = df_merge[df_merge['Celula'] != 'Beyond'].copy()

            if len(df_beyond) > 0:
                df_nova = df_beyond.copy()
                df_nova['Celula'] = 'Nova'

                df_absolute = df_beyond.copy()
                df_absolute['Celula'] = 'Absolute'

                # Combinar
                df_final = pd.concat([df_otros, df_nova, df_absolute], ignore_index=True)
                print(f"✓ {len(df_beyond)} proyectos Beyond duplicados como Nova y Absolute")
            else:
                df_final = df_otros

        # Agregar columna de Mes
        mes_actual = datetime.now().strftime('%Y-%m')
        df_final['Mes'] = mes_actual

        # Guardar con nombre dinámico
        nombre_archivo = f'metricas_sonarqube_{mes_actual}.xlsx'
        df_final.to_excel(nombre_archivo, index=False)

        print(f"\n✓ Archivo '{nombre_archivo}' generado exitosamente.")
        print(f"  Total de registros: {len(df_final)}")
        
    except FileNotFoundError:
        print(f"⚠️ Error: No se encontró el archivo '{nombre_archivo_celulas}'")
        print("  Guardando sin asignación de células...")
        df_metricas['Celula'] = ''
        mes_actual = datetime.now().strftime('%Y-%m')
        df_metricas['Mes'] = mes_actual
        nombre_archivo = f'metricas_sonarqube_{mes_actual}.xlsx'
        df_metricas.to_excel(nombre_archivo, index=False)
        print(f"✓ Archivo '{nombre_archivo}' generado sin células.")
    except Exception as e:
        print(f"✗ Error combinando con células: {e}")
        import traceback
        traceback.print_exc()

def main():
    print("="*60)
    print("SCRIPT DE MÉTRICAS SONARQUBE")
    print("="*60)
    
    proyectos = obtener_proyectos()
    print(f"✓ {len(proyectos)} proyectos obtenidos.")
    
    df_metricas = obtener_metricas(proyectos)
    print(f"\n✓ {len(df_metricas)} proyectos procesados con métricas.")
    
    combinar_con_celulas(df_metricas)

if __name__ == '__main__':
    main()