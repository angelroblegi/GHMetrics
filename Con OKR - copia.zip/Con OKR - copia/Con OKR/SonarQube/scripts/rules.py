"""
Lista TODAS las reglas de BUG y CODE_SMELL y cuántos issues activos tiene cada una.
Ejecución: python sonarqube_bugs_smells.py
"""
import requests, openpyxl
from openpyxl.styles import Font, PatternFill, Alignment
from collections import defaultdict

# ── CONFIGURACIÓN ────────────────────────────────────────────
SONAR_URL   = "http://hiroshima04s:9000"   # <-- URL de tu SonarQube
SONAR_TOKEN = "squ_9d4bf55717f19e3c05a873b1f350b96c07a636a1"           # <-- Tu token
OUTPUT_FILE = "reglas_sonar.xlsx"              # <-- Nombre del archivo de salida
# ─────────────────────────────────────────────────────────────

def get_session():
    s = requests.Session()
    s.auth = (SONAR_TOKEN, "")
    s.verify = False
    return s

def fetch_all_rules(session, rule_type):
    """Trae todas las reglas definidas en SonarQube para el tipo dado."""
    rules, page = [], 1
    while True:
        resp = session.get(f"{SONAR_URL}/api/rules/search", params={
            "types": rule_type, "ps": 500, "p": page,
            "f": "name,lang,langName,severity,status"
        }, timeout=30)
        resp.raise_for_status()
        data = resp.json()
        rules.extend(data["rules"])
        if len(rules) >= data["paging"]["total"]:
            break
        page += 1
    print(f"  [{rule_type}] {len(rules)} reglas encontradas")
    return rules

def fetch_issue_counts(session, rule_type):
    """Cuenta issues activos por regla (de todos los proyectos)."""
    counts = defaultdict(int)
    page = 1
    while True:
        resp = session.get(f"{SONAR_URL}/api/issues/search", params={
            "types": rule_type,
            "statuses": "OPEN,CONFIRMED,REOPENED",
            "ps": 500, "p": page,
        }, timeout=60)
        resp.raise_for_status()
        data = resp.json()
        for issue in data["issues"]:
            counts[issue.get("rule", "")] += 1
        total   = data["paging"]["total"]
        fetched = page * 500
        print(f"  [{rule_type}] Issues página {page} — {min(fetched, total)}/{total}...")
        if fetched >= total or fetched >= 10000:
            if fetched >= 10000:
                print(f"  AVISO: límite de 10.000 resultados alcanzado para {rule_type}.")
            break
        page += 1
    return counts

def write_sheet(ws, rules, counts, title):
    H_FILL = PatternFill("solid", start_color="1F4E79")
    H_FONT = Font(bold=True, color="FFFFFF", name="Arial", size=10)
    A_FILL = PatternFill("solid", start_color="DCE6F1")
    CENTER = Alignment(horizontal="center")

    ws.title = title
    cols   = ["Regla", "Nombre", "Lenguaje", "Severidad", "Estado", "Issues Activos"]
    widths = [38, 70, 22, 16, 14, 16]

    for c, h in enumerate(cols, 1):
        cell = ws.cell(1, c, h)
        cell.fill, cell.font, cell.alignment = H_FILL, H_FONT, CENTER
    ws.row_dimensions[1].height = 20

    # Ordenar: primero los que tienen issues (desc), luego los que tienen 0
    sorted_rules = sorted(rules, key=lambda r: counts.get(r["key"], 0), reverse=True)

    for i, r in enumerate(sorted_rules, 2):
        row_data = [
            r.get("key", ""),
            r.get("name", ""),
            r.get("langName") or r.get("lang", ""),
            r.get("severity", ""),
            r.get("status", ""),
            counts.get(r["key"], 0),
        ]
        for c, v in enumerate(row_data, 1):
            cell = ws.cell(i, c, v)
            cell.font = Font(name="Arial", size=9)
            if i % 2 == 0:
                cell.fill = A_FILL

    for c, w in enumerate(widths, 1):
        ws.column_dimensions[openpyxl.utils.get_column_letter(c)].width = w
    ws.auto_filter.ref = ws.dimensions

    total_issues = sum(counts.get(r["key"], 0) for r in rules)
    return total_issues

def write_summary(wb, bug_rules, bug_issues, smell_rules, smell_issues):
    ws = wb.create_sheet("Resumen")
    H_FILL = PatternFill("solid", start_color="1F4E79")
    H_FONT = Font(bold=True, color="FFFFFF", name="Arial", size=10)
    CENTER = Alignment(horizontal="center")

    rows = [
        ("Categoría",  "Reglas totales", "Issues activos"),
        ("BUG",         len(bug_rules),   bug_issues),
        ("CODE_SMELL",  len(smell_rules), smell_issues),
        ("TOTAL",       len(bug_rules)+len(smell_rules), bug_issues+smell_issues),
    ]
    for i, row in enumerate(rows, 1):
        for c, val in enumerate(row, 1):
            cell = ws.cell(i, c, val)
            if i == 1:
                cell.fill, cell.font, cell.alignment = H_FILL, H_FONT, CENTER
            elif i == len(rows):
                cell.font = Font(name="Arial", size=9, bold=True)
            else:
                cell.font = Font(name="Arial", size=9)

    ws.column_dimensions["A"].width = 20
    ws.column_dimensions["B"].width = 18
    ws.column_dimensions["C"].width = 18

def main():
    session = get_session()

    print("Obteniendo todas las reglas...")
    bug_rules   = fetch_all_rules(session, "BUG")
    smell_rules = fetch_all_rules(session, "CODE_SMELL")

    print("\nContando issues activos...")
    bug_counts   = fetch_issue_counts(session, "BUG")
    smell_counts = fetch_issue_counts(session, "CODE_SMELL")

    wb = openpyxl.Workbook()
    bug_total   = write_sheet(wb.active,         bug_rules,   bug_counts,   "Bugs")
    smell_total = write_sheet(wb.create_sheet(),  smell_rules, smell_counts, "Code Smells")
    write_summary(wb, bug_rules, bug_total, smell_rules, smell_total)
    wb.save(OUTPUT_FILE)

    print(f"\nArchivo: {OUTPUT_FILE}")
    print(f"BUG        — {len(bug_rules):>4} reglas | {bug_total:>6} issues activos")
    print(f"CODE_SMELL — {len(smell_rules):>4} reglas | {smell_total:>6} issues activos")

if __name__ == "__main__":
    main()