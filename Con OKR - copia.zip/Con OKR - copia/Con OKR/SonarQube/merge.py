import streamlit as st
import pandas as pd
import io
from openpyxl import load_workbook
from openpyxl.styles import PatternFill, Font, Alignment
import re

st.set_page_config(
    page_title="Excel Merger",
    page_icon="🔗",
    layout="wide"
)

st.markdown("""
<style>
    .main-title { font-size: 2rem; font-weight: 700; color: #1a1a2e; margin-bottom: 0.2rem; }
    .subtitle { color: #666; margin-bottom: 2rem; }
    .step-badge {
        background: #4f46e5; color: white; border-radius: 50%;
        width: 28px; height: 28px; display: inline-flex;
        align-items: center; justify-content: center;
        font-weight: bold; font-size: 0.85rem; margin-right: 8px;
    }
    .step-title { font-size: 1.1rem; font-weight: 600; color: #1a1a2e; }
    .info-box {
        background: #f0f4ff; border-left: 4px solid #4f46e5;
        padding: 12px 16px; border-radius: 4px; margin: 12px 0;
    }
    .success-box {
        background: #f0fdf4; border-left: 4px solid #16a34a;
        padding: 12px 16px; border-radius: 4px; margin: 12px 0;
    }
    .preview-header { font-weight: 600; color: #374151; margin-bottom: 6px; }
</style>
""", unsafe_allow_html=True)

st.markdown('<div class="main-title">🔗 Excel Merger</div>', unsafe_allow_html=True)
st.markdown('<div class="subtitle">Relaciona y completa columnas entre dos archivos Excel usando una columna clave en común.</div>', unsafe_allow_html=True)

def normalize(val):
    if pd.isna(val):
        return ""
    return re.sub(r'\s+', ' ', str(val).strip().lower())

def load_excel(file):
    xls = pd.ExcelFile(file)
    sheets = {}
    for name in xls.sheet_names:
        df = pd.read_excel(xls, sheet_name=name)
        sheets[name] = df
    return sheets

def fuzzy_match(a, b):
    return normalize(a) == normalize(b)

# ─── STEP 1: Upload ────────────────────────────────────────────────────────────
st.markdown("---")
col_badge, col_title = st.columns([0.05, 0.95])
st.markdown('<span class="step-badge">1</span><span class="step-title">Sube los dos archivos Excel</span>', unsafe_allow_html=True)

col1, col2 = st.columns(2)
with col1:
    st.markdown("**📄 Archivo BASE** — el que quieres completar")
    file_base = st.file_uploader("Archivo base", type=["xlsx", "xls"], key="base", label_visibility="collapsed")
with col2:
    st.markdown("**📋 Archivo FUENTE** — el que tiene los datos completos")
    file_source = st.file_uploader("Archivo fuente", type=["xlsx", "xls"], key="source", label_visibility="collapsed")

if not file_base or not file_source:
    st.markdown('<div class="info-box">⬆️ Sube ambos archivos para continuar.</div>', unsafe_allow_html=True)
    st.stop()

# Load sheets
with st.spinner("Leyendo archivos..."):
    base_sheets = load_excel(file_base)
    source_sheets = load_excel(file_source)

# ─── STEP 2: Sheet selection ───────────────────────────────────────────────────
st.markdown("---")
st.markdown('<span class="step-badge">2</span><span class="step-title">Selecciona las hojas a usar</span>', unsafe_allow_html=True)

col1, col2 = st.columns(2)
with col1:
    base_sheet = st.selectbox("Hoja del archivo BASE", list(base_sheets.keys()), key="base_sheet")
with col2:
    source_sheet = st.selectbox("Hoja del archivo FUENTE", list(source_sheets.keys()), key="source_sheet")

df_base = base_sheets[base_sheet].copy()
df_source = source_sheets[source_sheet].copy()

col1, col2 = st.columns(2)
with col1:
    st.markdown('<div class="preview-header">Vista previa — BASE</div>', unsafe_allow_html=True)
    st.dataframe(df_base.head(5), use_container_width=True, hide_index=True)
with col2:
    st.markdown('<div class="preview-header">Vista previa — FUENTE</div>', unsafe_allow_html=True)
    st.dataframe(df_source.head(5), use_container_width=True, hide_index=True)

# ─── STEP 3: Key column ────────────────────────────────────────────────────────
st.markdown("---")
st.markdown('<span class="step-badge">3</span><span class="step-title">¿Por cuál columna quieres relacionar los dos archivos?</span>', unsafe_allow_html=True)

base_cols = list(df_base.columns)
source_cols = list(df_source.columns)

col1, col2 = st.columns(2)
with col1:
    key_base = st.selectbox("Columna clave en BASE", base_cols, key="key_base",
                            index=0 if base_cols else 0)
with col2:
    # Try to find same name in source
    default_idx = source_cols.index(key_base) if key_base in source_cols else 0
    key_source = st.selectbox("Columna clave en FUENTE", source_cols, key="key_source",
                              index=default_idx)

st.markdown(f'<div class="info-box">Se relacionará: <b>BASE[{key_base}]</b> ↔ <b>FUENTE[{key_source}]</b></div>', unsafe_allow_html=True)

# ─── STEP 4: Choose columns to fill ───────────────────────────────────────────
st.markdown("---")
st.markdown('<span class="step-badge">4</span><span class="step-title">¿Qué columnas de la FUENTE quieres traer al BASE?</span>', unsafe_allow_html=True)

available_source_cols = [c for c in source_cols if c != key_source]

cols_to_fill = st.multiselect(
    "Columnas a traer desde FUENTE",
    available_source_cols,
    help="Selecciona una o más columnas que quieres copiar al archivo base."
)

if not cols_to_fill:
    st.markdown('<div class="info-box">📌 Selecciona al menos una columna de la FUENTE para continuar.</div>', unsafe_allow_html=True)
    st.stop()

# ─── STEP 5: Mapping mode ──────────────────────────────────────────────────────
st.markdown("---")
st.markdown('<span class="step-badge">5</span><span class="step-title">¿Cómo manejar las columnas destino en el BASE?</span>', unsafe_allow_html=True)

col1, col2 = st.columns(2)
with col1:
    fill_mode = st.radio(
        "Modo de llenado",
        ["Solo rellenar vacíos", "Sobreescribir todo"],
        help="'Solo rellenar vacíos' respeta valores ya existentes. 'Sobreescribir todo' reemplaza con los datos de la fuente."
    )
with col2:
    match_mode = st.radio(
        "Precisión del match",
        ["Exacto (sensible a mayúsculas)", "Flexible (ignora mayúsculas y espacios extra)"],
        help="Flexible es útil cuando los nombres tienen diferencias de capitalización o espacios."
    )

# Column name mapping
st.markdown("**Mapeo de nombres de columnas** (ajusta si los nombres difieren entre archivos)")
col_mapping = {}
for col in cols_to_fill:
    c1, c2 = st.columns(2)
    with c1:
        st.markdown(f"Columna en FUENTE: **{col}**")
    with c2:
        existing = [c for c in base_cols if c != key_base]
        options = ["➕ Crear nueva columna"] + existing
        # Try to find matching name
        default_opt = col if col in existing else "➕ Crear nueva columna"
        default_idx = options.index(default_opt) if default_opt in options else 0
        dest = st.selectbox(f"→ Columna destino en BASE para '{col}'", options, index=default_idx, key=f"map_{col}")
        col_mapping[col] = dest

# ─── STEP 6: Preview & Execute ────────────────────────────────────────────────
st.markdown("---")
st.markdown('<span class="step-badge">6</span><span class="step-title">Previsualiza y genera el archivo</span>', unsafe_allow_html=True)

if st.button("🔍 Previsualizar resultado", type="primary"):
    df_result = df_base.copy()
    use_flexible = "Flexible" in match_mode
    only_empty = "vacíos" in fill_mode

    # Build lookup from source
    lookup = {}
    for _, row in df_source.iterrows():
        k = normalize(row[key_source]) if use_flexible else str(row[key_source]).strip()
        lookup[k] = row

    matched = 0
    not_matched = []

    for idx, row in df_result.iterrows():
        k = normalize(row[key_base]) if use_flexible else str(row[key_base]).strip()
        source_row = lookup.get(k)
        if source_row is not None:
            matched += 1
            for src_col, dest_col in col_mapping.items():
                val = source_row[src_col]
                if dest_col == "➕ Crear nueva columna":
                    dest_col = src_col
                    if dest_col not in df_result.columns:
                        df_result[dest_col] = None
                if only_empty:
                    current = df_result.at[idx, dest_col] if dest_col in df_result.columns else None
                    if pd.isna(current) or str(current).strip() == "" or str(current).strip().lower() in ["vacio", "vacío", "n/a", "none"]:
                        df_result.at[idx, dest_col] = val
                else:
                    if dest_col not in df_result.columns:
                        df_result[dest_col] = None
                    df_result.at[idx, dest_col] = val
        else:
            not_matched.append(str(row[key_base]))

    st.session_state["df_result"] = df_result
    st.session_state["matched"] = matched
    st.session_state["not_matched"] = not_matched

if "df_result" in st.session_state:
    df_result = st.session_state["df_result"]
    matched = st.session_state["matched"]
    not_matched = st.session_state["not_matched"]

    total = len(df_base)
    st.markdown(f'<div class="success-box">✅ <b>{matched}/{total}</b> filas relacionadas correctamente.</div>', unsafe_allow_html=True)

    if not_matched:
        with st.expander(f"⚠️ {len(not_matched)} fila(s) sin match — ver detalles"):
            for nm in not_matched:
                st.markdown(f"- `{nm}`")

    st.markdown("**Vista previa del resultado:**")
    st.dataframe(df_result, use_container_width=True, hide_index=True)

    # Export
    st.markdown("---")
    st.markdown('<span class="step-badge">7</span><span class="step-title">Descarga el archivo final</span>', unsafe_allow_html=True)

    output_name = st.text_input("Nombre del archivo de salida", value="resultado_merged.xlsx")
    if not output_name.endswith(".xlsx"):
        output_name += ".xlsx"

    # Write to buffer with basic styling
    buf = io.BytesIO()
    with pd.ExcelWriter(buf, engine="openpyxl") as writer:
        df_result.to_excel(writer, index=False, sheet_name="Resultado")
        wb = writer.book
        ws = writer.sheets["Resultado"]

        header_fill = PatternFill("solid", start_color="4F46E5", end_color="4F46E5")
        header_font = Font(bold=True, color="FFFFFF", name="Arial", size=11)
        for cell in ws[1]:
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = Alignment(horizontal="center", vertical="center")

        for col_cells in ws.columns:
            max_len = max((len(str(c.value or "")) for c in col_cells), default=10)
            ws.column_dimensions[col_cells[0].column_letter].width = min(max_len + 4, 40)

    buf.seek(0)
    st.download_button(
        label="⬇️ Descargar Excel resultante",
        data=buf,
        file_name=output_name,
        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        type="primary"
    )
