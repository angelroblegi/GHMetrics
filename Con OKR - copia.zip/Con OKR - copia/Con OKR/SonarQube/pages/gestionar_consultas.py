import streamlit as st
import os
from datetime import datetime

st.set_page_config(page_title="Gestionar consultas a SonarQube", layout="wide")

st.title("🔧 Gestión de consultas a las API de SonarQube")

if "rol" not in st.session_state or st.session_state["rol"] != "admin":
    st.error("🚫 No tienes permiso para ver esta página. Por favor inicia sesión como admin.")
    st.stop()

opciones = ["Métricas mensuales (consulta_api.py)", "Último análisis proyectos (ultimomes.py)"]
tabs = st.tabs(opciones)

# ---- TAB 1: consulta_api.py ----
with tabs[0]:
    st.header("Consulta y descarga de métricas mensuales")
    btn = st.button("Ejecutar consulta y generar Excel (consulta_api.py)")
    if btn:
        with st.spinner("Ejecutando extracción, esto puede tardar varios minutos..."):
            salida = os.popen('python scripts/consulta_api.py').read()
            st.info(salida)
        # Buscar archivo generado
        mes = datetime.now().strftime('%Y-%m')
        nombre_archivo = f"metricas_sonarqube_{mes}.xlsx"
        if os.path.exists(nombre_archivo):
            with open(nombre_archivo, 'rb') as f:
                st.success(f"Archivo generado: {nombre_archivo}")
                st.download_button('Descargar archivo .xlsx', data=f.read(), file_name=nombre_archivo, mime='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
        else:
            st.error(f"No se encontró el archivo esperado después de la ejecución: {nombre_archivo}")

# ---- TAB 2: ultimomes.py ----
with tabs[1]:
    st.header("Consulta y descarga de último análisis por proyecto")
    btn2 = st.button("Ejecutar consulta y generar Excel (ultimomes.py)")
    if btn2:
        with st.spinner("Ejecutando extracción de últimos análisis, puede tardar varios minutos..."):
            salida2 = os.popen('python scripts/ultimomes.py').read()
            st.info(salida2)
        # Por default el script guarda un archivo que contiene 'proyectos_sonarqube' en el nombre
        ult_archivos = [f for f in os.listdir('.') if f.startswith('proyectos_sonarqube') and f.endswith('.xlsx')]
        ult_archivos = sorted(ult_archivos, reverse=True)  # El más reciente primero
        if ult_archivos:
            archivo = ult_archivos[0]
            with open(archivo, 'rb') as f:
                st.success(f"Archivo generado: {archivo}")
                st.download_button('Descargar archivo .xlsx', data=f.read(), file_name=archivo, mime='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
        else:
            st.error("No se encontró un archivo .xlsx generado por el script ultimomes.py.")