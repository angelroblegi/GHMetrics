import streamlit as st
import pandas as pd
import os
import re
import base64
import requests
import time
from datetime import datetime, date, time as dtime, timedelta
from urllib.parse import urlparse, parse_qs


st.set_page_config(page_title="Lanzar Pipelines Azure", layout="wide")

# Solo admin
if "rol" not in st.session_state or st.session_state["rol"] != "admin":
    st.warning("🚫 No tienes permiso para ver esta página. Por favor inicia sesión como admin.")
    st.stop()

st.title("🚀 Lanzar Pipelines de Azure DevOps")
st.caption("Busca componentes, selecciónalos y ejecuta sus pipelines en Azure DevOps")

ARCHIVO_INVENTARIO = os.path.join("data", "Proyectos_filtrados.xlsx")

@st.cache_data
def cargar_inventario(path):
    df = pd.read_excel(path)
    df.columns = df.columns.str.strip()
    # Normalizar nombres esperados
    nombre_col = None
    for c in ["NombreProyecto", "Proyecto", "Componente", "Nombre"]:
        if c in df.columns:
            nombre_col = c
            break
    if nombre_col is None:
        raise ValueError("No se encontró una columna de nombre de proyecto (p. ej., 'NombreProyecto').")

    if "Pipeline" not in df.columns:
        raise ValueError("No se encontró la columna 'Pipeline' con el enlace de Azure DevOps.")

    df = df[[nombre_col, "Pipeline"]].rename(columns={nombre_col: "NombreProyecto"})
    # Quitar filas sin pipeline
    df = df[df["Pipeline"].notna() & (df["Pipeline"].astype(str).str.strip() != "")].copy()
    return df

def _basic_auth_header(pat):
    token_bytes = (":" + pat).encode("utf-8")
    b64 = base64.b64encode(token_bytes).decode("utf-8")
    return {"Authorization": f"Basic {b64}"}

def parse_pipeline_info(url):
    """Intentar extraer organization, project y pipelineId desde un enlace típico de Azure DevOps.

    Soporta formatos comunes:
    - https://dev.azure.com/{org}/{project}/_build?definitionId={id}
    - https://dev.azure.com/{org}/{project}/_build/latest?definitionId={id}
    - https://dev.azure.com/{org}/{project}/_build?definitionId={id}&...
    - https://dev.azure.com/{org}/{project}/_apis/pipelines/{id}
    - https://dev.azure.com/{org}/{project}/_build?buildId=... (no sirve para disparar, se ignora)
    """
    try:
        parsed = urlparse(url)
        path_parts = [p for p in parsed.path.split("/") if p]
        if len(path_parts) < 2:
            return None
        org = path_parts[0]
        project = path_parts[1]

        # Caso API pipelines
        # /{org}/{project}/_apis/pipelines/{id}
        if len(path_parts) >= 5 and path_parts[2] == "_apis" and path_parts[3] == "pipelines":
            pipeline_id = int(path_parts[4])
            return {"org": org, "project": project, "pipeline_id": pipeline_id, "api": "pipelines"}

        # Caso UI _build con definitionId (Build Pipelines clásico)
        # /{org}/{project}/_build?definitionId={id}
        if len(path_parts) >= 3 and path_parts[2] == "_build":
            qs = parse_qs(parsed.query or "")
            if "definitionId" in qs:
                pipeline_id = int(qs["definitionId"][0])
                return {"org": org, "project": project, "pipeline_id": pipeline_id, "api": "builds"}

        return None
    except Exception:
        return None

def disparar_pipeline(token_pat, org, project, pipeline_id, api_tipo="builds", verify_ssl=True):
    headers = {
        "Content-Type": "application/json",
        **_basic_auth_header(token_pat)
    }

    if api_tipo == "pipelines":
        # Nueva API de Pipelines (YAML)
        url = f"https://dev.azure.com/{org}/{project}/_apis/pipelines/{pipeline_id}/runs?api-version=7.1-preview.1"
        payload = {}
    else:
        # API de Builds clásico
        url = f"https://dev.azure.com/{org}/{project}/_apis/build/builds?api-version=7.1"
        payload = {"definition": {"id": pipeline_id}}

    resp = requests.post(url, json=payload, headers=headers, timeout=30, verify=verify_ssl)
    return resp

def obtener_estado_ejecucion(token_pat, org, project, identificadores, verify_ssl=True):
    """Consultar estado actual del run/build.
    identificadores: dict con claves dependiendo del tipo
      - {"api": "builds", "build_id": int}
      - {"api": "pipelines", "pipeline_id": int, "run_id": int}
    Devuelve (status, result, web_url)
    """
    headers = {
        **_basic_auth_header(token_pat)
    }
    try:
        if identificadores.get("api") == "builds":
            build_id = identificadores["build_id"]
            url = f"https://dev.azure.com/{org}/{project}/_apis/build/builds/{build_id}?api-version=7.1"
            r = requests.get(url, headers=headers, timeout=20, verify=verify_ssl)
            if r.status_code >= 400:
                return ("error", None, None, r.text[:300])
            data = r.json()
            status = str(data.get("status"))  # notStarted, inProgress, completed
            result = data.get("result")  # succeeded, failed, canceled, partiallySucceeded
            web_url = data.get("_links", {}).get("web", {}).get("href")
            return (status, result, web_url, None)
        else:
            pipeline_id = identificadores["pipeline_id"]
            run_id = identificadores["run_id"]
            url = f"https://dev.azure.com/{org}/{project}/_apis/pipelines/{pipeline_id}/runs/{run_id}?api-version=7.1-preview.1"
            r = requests.get(url, headers=headers, timeout=20, verify=verify_ssl)
            if r.status_code >= 400:
                return ("error", None, None, r.text[:300])
            data = r.json()
            status = str(data.get("state"))  # notStarted, inProgress, completed
            result = data.get("result")  # succeeded, failed, canceled
            web_url = data.get("_links", {}).get("web", {}).get("href")
            return (status, result, web_url, None)
    except requests.RequestException as e:
        return ("error", None, None, str(e)[:300])


# --- UI ---

if not os.path.exists(ARCHIVO_INVENTARIO):
    st.error("No se encontró 'data/Proyectos_filtrados.xlsx'.")
    st.stop()

try:
    df = cargar_inventario(ARCHIVO_INVENTARIO)
except Exception as e:
    st.error(f"Error cargando inventario: {e}")
    st.stop()

with st.sidebar:
    st.markdown("**Autenticación Azure DevOps**")
    pat = st.text_input("Token PAT", type="password", help="Se usará solo en esta sesión para autenticar contra Azure DevOps.")
    st.caption("El token no se guarda en disco; permanece en la sesión.")
    ignore_ssl = st.checkbox("Ignorar verificación SSL (no recomendado)", value=False, help="Úsalo solo si tu red usa un proxy/certificado corporativo que rompe TLS.")

st.markdown("### 1) Buscar y seleccionar componentes")
col_b, col_sel = st.columns([2, 3])

with col_b:
    term = st.text_input("Buscar por nombre del proyecto")

df_view = df.copy()
if term:
    df_view = df_view[df_view["NombreProyecto"].str.contains(term, case=False, na=False)]

df_view = df_view.reset_index(drop=True)

st.dataframe(df_view, use_container_width=True, height=300)

nombres = df_view["NombreProyecto"].tolist()
seleccion = st.multiselect("Selecciona uno o varios proyectos", opciones := nombres, default=[])

st.markdown("### 2) Lanzar pipelines seleccionados")
col_btn1, col_btn2 = st.columns([1, 5])

with col_btn1:
    lanzar = st.button("🚀 Lanzar pipelines")

resultados = []

# Configurar retraso entre ejecuciones (por defecto 10 minutos)
delay_minutes = st.number_input("Retraso entre ejecuciones (minutos)", min_value=0, max_value=180, value=10, step=1, help="Para no saturar los agentes, se esperará este tiempo entre cada pipeline.")

# Programación de inicio a una hora específica (opcional)
st.markdown("### 3) Programación opcional de inicio")
col_fecha, col_hora = st.columns(2)
with col_fecha:
    fecha_programada = st.date_input("Fecha de inicio", value=date.today())
with col_hora:
    hora_programada = st.time_input("Hora de inicio", value=dtime(hour=0, minute=0))

programar_inicio = st.checkbox("Programar inicio en la fecha/hora indicada", value=False)

# Monitoreo de resultados
st.markdown("### 4) Monitoreo de estado")
monitor = st.checkbox("Monitorear cada ejecución hasta finalizar", value=True)
poll_seconds = st.number_input("Intervalo de consulta (segundos)", min_value=5, max_value=120, value=15, step=5)
max_espera_min = st.number_input("Tiempo máximo por ejecución (min)", min_value=1, max_value=240, value=30, step=1)

if lanzar:
    if not seleccion:
        st.warning("Primero selecciona al menos un proyecto.")
    elif not pat:
        st.warning("Ingresa tu token PAT en la barra lateral.")
    else:
        subset = df_view[df_view["NombreProyecto"].isin(seleccion)]
        progress = st.progress(0)
        total = len(subset)
        with st.spinner("Ejecutando pipelines con retraso..."):
            # Esperar hasta la fecha/hora programada
            if programar_inicio:
                dt_programada = datetime.combine(fecha_programada, hora_programada)
                ahora = datetime.now()
                if dt_programada > ahora:
                    st.info(f"Esperando al inicio programado: {dt_programada}")
                    time.sleep((dt_programada - ahora).total_seconds())

            for idx, (_, fila) in enumerate(subset.iterrows()):
                if idx > 0 and delay_minutes > 0:
                    # Esperar entre ejecuciones
                    time.sleep(int(delay_minutes * 60))
                nombre = str(fila["NombreProyecto"]).strip()
                url = str(fila["Pipeline"]).strip()
                info = parse_pipeline_info(url)
                if not info:
                    resultados.append({"Proyecto": nombre, "Estado": "❌ No se pudo interpretar el enlace de pipeline", "Detalle": url})
                    continue

                try:
                    resp = disparar_pipeline(pat, info["org"], info["project"], info["pipeline_id"], info.get("api", "builds"), verify_ssl=not ignore_ssl)
                    if 200 <= resp.status_code < 300:
                        try:
                            data = resp.json()
                        except Exception:
                            data = {}
                        # Identificar IDs para monitoreo
                        identificadores = {"api": info.get("api", "builds")}
                        web_url = None
                        if identificadores["api"] == "builds":
                            build_id = data.get("id")
                            identificadores["build_id"] = build_id
                            web_url = data.get("_links", {}).get("web", {}).get("href")
                        else:
                            run_id = data.get("id")
                            identificadores["pipeline_id"] = info["pipeline_id"]
                            identificadores["run_id"] = run_id
                            web_url = data.get("_links", {}).get("web", {}).get("href")

                        estado_texto = "✅ Disparado"

                        if monitor and ((identificadores.get("build_id") is not None) or (identificadores.get("run_id") is not None)):
                            t0 = datetime.now()
                            while True:
                                status, result, url_web, err = obtener_estado_ejecucion(pat, info["org"], info["project"], identificadores, verify_ssl=not ignore_ssl)
                                if err:
                                    estado_texto = f"❌ Error monitoreo: {err[:80]}"
                                    break
                                # Estados de finalización
                                if str(status).lower() in ("completed", "finished") or str(result).lower() in ("succeeded", "failed", "canceled", "partiallySucceeded"):
                                    if result and str(result).lower() == "succeeded":
                                        estado_texto = "✅ Completado"
                                    elif result:
                                        estado_texto = f"❌ {str(result).capitalize()}"
                                    else:
                                        estado_texto = f"ℹ️ Estado: {status}"
                                    web_url = url_web or web_url
                                    break
                                if (datetime.now() - t0) > timedelta(minutes=int(max_espera_min)):
                                    estado_texto = f"⏱️ Tiempo máximo agotado (>{max_espera_min}m)"
                                    break
                                time.sleep(int(poll_seconds))

                        resultados.append({"Proyecto": nombre, "Estado": estado_texto, "Detalle": web_url or ""})
                    else:
                        resultados.append({"Proyecto": nombre, "Estado": f"❌ Error {resp.status_code}", "Detalle": resp.text[:500]})
                except requests.RequestException as e:
                    resultados.append({"Proyecto": nombre, "Estado": "❌ Error de red", "Detalle": str(e)[:300]})
                progress.progress(int(((idx + 1) / total) * 100))

if resultados:
    st.markdown("---")
    st.subheader("Resultados")
    df_res = pd.DataFrame(resultados)
    st.dataframe(df_res, use_container_width=True)

    # Conteo rápido
    ok = sum(1 for r in resultados if str(r.get("Estado", "")).startswith("✅"))
    fail = len(resultados) - ok
    st.success(f"Pipelines lanzados correctamente: {ok}")
    if fail:
        st.error(f"Fallidos: {fail}")


