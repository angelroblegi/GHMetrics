import streamlit as st
import pandas as pd
import os
import base64
import requests
from urllib.parse import urlparse, parse_qs


st.set_page_config(page_title="Prueba: Lanzar un Pipeline", layout="centered")

# -------------------------------------------------------
# Pega aquí tu token PAT de Azure DevOps
# EJEMPLO: AZDO_PAT = "azdopersonalaccesstoken123..."
AZDO_PAT = ""  # <-- PON AQUÍ TU TOKEN PAT
# -------------------------------------------------------

# Solo admin
if "rol" not in st.session_state or st.session_state["rol"] != "admin":
    st.warning("🚫 No tienes permiso para ver esta página. Por favor inicia sesión como admin.")
    st.stop()

st.title("🧪 Prueba: Lanzar un Pipeline de Azure")
st.caption("Selecciona un componente y lanza su pipeline (sin opciones avanzadas)")

ARCHIVO_INVENTARIO = os.path.join("data", "Proyectos_filtrados.xlsx")

@st.cache_data
def cargar_inventario(path):
    df = pd.read_excel(path)
    df.columns = df.columns.str.strip()
    if "NombreProyecto" not in df.columns:
        raise ValueError("No se encontró la columna 'NombreProyecto'.")
    if "Pipeline" not in df.columns:
        raise ValueError("No se encontró la columna 'Pipeline'.")
    df = df[["NombreProyecto", "Pipeline"]].dropna(subset=["Pipeline"]).copy()
    return df

def _basic_auth_header(pat):
    token_bytes = (":" + pat).encode("utf-8")
    b64 = base64.b64encode(token_bytes).decode("utf-8")
    return {"Authorization": f"Basic {b64}"}

def parse_pipeline_info(url):
    try:
        parsed = urlparse(url)
        path_parts = [p for p in parsed.path.split("/") if p]
        if len(path_parts) < 2:
            return None
        org = path_parts[0]
        project = path_parts[1]
        # API pipelines YAML
        if len(path_parts) >= 5 and path_parts[2] == "_apis" and path_parts[3] == "pipelines":
            pipeline_id = int(path_parts[4])
            return {"org": org, "project": project, "pipeline_id": pipeline_id, "api": "pipelines"}
        # UI _build con definitionId (Build clásico)
        if len(path_parts) >= 3 and path_parts[2] == "_build":
            qs = parse_qs(parsed.query or "")
            if "definitionId" in qs:
                pipeline_id = int(qs["definitionId"][0])
                return {"org": org, "project": project, "pipeline_id": pipeline_id, "api": "builds"}
        return None
    except Exception:
        return None

def disparar_pipeline(token_pat, org, project, pipeline_id, api_tipo="builds", verify_ssl=True):
    headers = {
        "Content-Type": "application/json",
        **_basic_auth_header(token_pat)
    }
    if api_tipo == "pipelines":
        url = f"https://dev.azure.com/{org}/{project}/_apis/pipelines/{pipeline_id}/runs?api-version=7.1-preview.1"
        payload = {}
    else:
        url = f"https://dev.azure.com/{org}/{project}/_apis/build/builds?api-version=7.1"
        payload = {"definition": {"id": pipeline_id}}
    return requests.post(url, json=payload, headers=headers, timeout=30, verify=verify_ssl)

if not os.path.exists(ARCHIVO_INVENTARIO):
    st.error("No se encontró 'data/Proyectos_filtrados.xlsx'.")
    st.stop()

try:
    df = cargar_inventario(ARCHIVO_INVENTARIO)
except Exception as e:
    st.error(f"Error cargando inventario: {e}")
    st.stop()

opciones = df["NombreProyecto"].tolist()
proyecto = st.selectbox("Selecciona un componente", opciones)
ignore_ssl = st.checkbox("Ignorar verificación SSL (no recomendado)")

col1, col2 = st.columns(2)
with col1:
    lanzar = st.button("🚀 Lanzar pipeline")
with col2:
    st.info("Recuerda pegar tu PAT en la parte superior del archivo (variable AZDO_PAT).")

if lanzar:
    if not AZDO_PAT:
        st.error("Debes pegar tu token PAT en la variable AZDO_PAT al inicio del archivo.")
        st.stop()
    fila = df[df["NombreProyecto"] == proyecto].iloc[0]
    url = str(fila["Pipeline"]).strip()
    info = parse_pipeline_info(url)
    if not info:
        st.error("No se pudo interpretar el enlace de pipeline para este componente.")
        st.stop()
    try:
        r = disparar_pipeline(AZDO_PAT, info["org"], info["project"], info["pipeline_id"], info.get("api", "builds"), verify_ssl=not ignore_ssl)
        if 200 <= r.status_code < 300:
            st.success("Pipeline disparado correctamente.")
            try:
                data = r.json()
                web_url = data.get("_links", {}).get("web", {}).get("href")
                if web_url:
                    st.markdown(f"[Ver ejecución]({web_url})")
            except Exception:
                pass
        else:
            st.error(f"Error {r.status_code}: {r.text[:500]}")
    except requests.RequestException as e:
        st.error(f"Error de red: {str(e)[:300]}")


