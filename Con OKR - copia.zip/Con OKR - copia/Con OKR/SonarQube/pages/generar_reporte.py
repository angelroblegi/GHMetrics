import streamlit as st
import pandas as pd
import os
import glob
from datetime import datetime
import math
from io import BytesIO
from openpyxl import Workbook
from openpyxl.styles import (
    Font, PatternFill, Alignment, Border, Side
)
from openpyxl.utils import get_column_letter

# ── CONFIG ──────────────────────────────────────────────────
if "rol" not in st.session_state:
    st.warning("⚠️ Por favor inicia sesión para continuar.")
    st.stop()

ARCHIVO_SELECCION = "data/seleccion_proyectos.csv"
ARCHIVO_PARAMETROS = "data/parametros_metricas.csv"
ARCHIVO_METAS = "data/metas_progreso.csv"
ARCHIVO_CONFIGURACION_METRICAS = "data/configuracion_metricas.csv"
ARCHIVO_CONFIGURACION_NA = "data/configuracion_na.csv"
UPLOAD_DIR = "uploads"

PROYECTOS_EXCLUIR_COVERAGE = [
    "AEL.DebidaDiligencia.FrontEnd:Quality",
    "AEL.NominaElectronica.FrontEnd:Quality"
]

# ── HELPERS ──────────────────────────────────────────────────
def redondear_hacia_arriba(valor):
    if pd.isna(valor):
        return valor
    return int(valor + 0.5)

def cargar_datos(path):
    df = pd.read_excel(path)
    df.columns = df.columns.str.strip()
    df['coverage'] = pd.to_numeric(df['coverage'], errors='coerce')
    if 'duplicated_lines_density' in df.columns:
        df['complexity'] = df['duplicated_lines_density'].astype(str).str.strip().str.upper()
        valid_ratings = ['A', 'B', 'C', 'D', 'E']
        df['complexity'] = df['complexity'].apply(lambda x: x if x in valid_ratings else None)
    else:
        df['complexity'] = None
    bug_cols = ['bugs_blocker', 'bugs_critical', 'bugs_major', 'bugs_minor']
    for col in bug_cols:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors='coerce').fillna(0).astype(int)
    return df

def cargar_todos_los_datos():
    archivos = glob.glob(os.path.join(UPLOAD_DIR, "metricas_*.xlsx"))
    dfs = []
    for archivo in archivos:
        df_temp = cargar_datos(archivo)
        mes = os.path.basename(archivo).split("_")[1].replace(".xlsx", "")
        df_temp['Mes'] = pd.to_datetime(mes, format="%Y-%m")
        dfs.append(df_temp)
    return pd.concat(dfs) if dfs else pd.DataFrame()

def cargar_seleccion():
    if os.path.exists(ARCHIVO_SELECCION):
        df_sel = pd.read_csv(ARCHIVO_SELECCION)
        seleccion = {}
        for celula in df_sel['Celula'].unique():
            seleccion[celula] = df_sel[df_sel['Celula'] == celula]['NombreProyecto'].tolist()
        return seleccion
    return {}

def cargar_parametros():
    if os.path.exists(ARCHIVO_PARAMETROS):
        df_param = pd.read_csv(ARCHIVO_PARAMETROS, sep=';')
        if not df_param.empty:
            fila = df_param.iloc[0]
            return {
                "security_rating": fila.get("security_rating", "A,B,C,D,E"),
                "reliability_rating": fila.get("reliability_rating", "A,B,C,D,E"),
                "sqale_rating": fila.get("sqale_rating", "A,B,C,D,E"),
                "duplicated_lines_density": fila.get("duplicated_lines_density", "A,B,C,D,E"),
                "coverage_min": float(fila.get("coverage_min", 0))
            }
    return {"security_rating": "A,B,C,D,E", "reliability_rating": "A,B,C,D,E",
            "sqale_rating": "A,B,C,D,E", "duplicated_lines_density": "A,B,C,D,E", "coverage_min": 0}

def cargar_metas():
    if os.path.exists(ARCHIVO_METAS):
        df_metas = pd.read_csv(ARCHIVO_METAS, sep=';')
        if not df_metas.empty:
            fila = df_metas.iloc[0]
            return {
                "meta_confiabilidad": float(fila.get("meta_confiabilidad", 90)),
                "meta_mantenibilidad": float(fila.get("meta_mantenibilidad", 90)),
                "meta_cobertura": float(fila.get("meta_cobertura", 70)),
                "meta_complejidad": float(fila.get("meta_complejidad", 90))
            }
    return {"meta_confiabilidad": 90.0, "meta_mantenibilidad": 90.0,
            "meta_cobertura": 70.0, "meta_complejidad": 90.0}

def cargar_configuracion_metricas():
    if os.path.exists(ARCHIVO_CONFIGURACION_METRICAS):
        df = pd.read_csv(ARCHIVO_CONFIGURACION_METRICAS, sep=';')
        if not df.empty:
            fila = df.iloc[0]
            return {
                "cobertura_usar_seleccionados": fila.get("cobertura_usar_seleccionados", True),
                "confiabilidad_usar_seleccionados": fila.get("confiabilidad_usar_seleccionados", False),
                "mantenibilidad_usar_seleccionados": fila.get("mantenibilidad_usar_seleccionados", False),
                "complejidad_usar_seleccionados": fila.get("complejidad_usar_seleccionados", False),
            }
    return {"cobertura_usar_seleccionados": True, "confiabilidad_usar_seleccionados": False,
            "mantenibilidad_usar_seleccionados": False, "complejidad_usar_seleccionados": False}

def cargar_configuracion_na():
    if os.path.exists(ARCHIVO_CONFIGURACION_NA):
        df = pd.read_csv(ARCHIVO_CONFIGURACION_NA, sep=';')
        if not df.empty:
            fila = df.iloc[0]
            return {
                "incluir_na_confiabilidad": fila.get("incluir_na_confiabilidad", False),
                "incluir_na_mantenibilidad": fila.get("incluir_na_mantenibilidad", False),
                "incluir_na_cobertura": fila.get("incluir_na_cobertura", False),
                "incluir_na_complejidad": fila.get("incluir_na_complejidad", False),
            }
    return {"incluir_na_confiabilidad": False, "incluir_na_mantenibilidad": False,
            "incluir_na_cobertura": False, "incluir_na_complejidad": False}

def filtrar_por_metrica(df, celula, seleccion_proyectos, usar_seleccionados):
    if usar_seleccionados and celula in seleccion_proyectos and seleccion_proyectos[celula]:
        return df[(df['Celula'] == celula) & (df['NombreProyecto'].isin(seleccion_proyectos[celula]))]
    return df[df['Celula'] == celula]

# ── CALCULOS ─────────────────────────────────────────────────
def calcular_okr(df_celula_mes, df_cobertura_filtrado, parametros, metas, config_na):
    umbral_conf = parametros["reliability_rating"].split(",")
    umbral_mant = parametros["sqale_rating"].split(",")
    umbral_comp = parametros["duplicated_lines_density"].split(",")
    cobertura_min = parametros["coverage_min"]

    okr_rows = []

    def calcular_metrica(nombre, df, col, umbral, incluir_na, meta_key):
        base = df if incluir_na else df.dropna(subset=[col])
        if base.empty:
            return
        total = len(base)
        cumplen = len(base[base[col].isin(umbral)])
        meta = metas[meta_key]
        objetivo = redondear_hacia_arriba(total * (meta / 100))
        okr = redondear_hacia_arriba((cumplen / objetivo) * 100) if objetivo > 0 else 0
        okr_rows.append({
            'Métrica': nombre,
            'Total Componentes': total,
            'Meta Configurada (%)': meta,
            'Componentes Objetivo': objetivo,
            'Componentes Cumplen': cumplen,
            'Cumplimiento OKR (%)': okr,
            'Estado': '✅ Cumple' if okr >= 100 else '⚠️ No cumple'
        })

    calcular_metrica('Confiabilidad', df_celula_mes, 'reliability_rating',
                     umbral_conf, config_na["incluir_na_confiabilidad"], 'meta_confiabilidad')
    calcular_metrica('Mantenibilidad', df_celula_mes, 'sqale_rating',
                     umbral_mant, config_na["incluir_na_mantenibilidad"], 'meta_mantenibilidad')
    calcular_metrica('Complejidad', df_celula_mes, 'complexity',
                     umbral_comp, config_na["incluir_na_complejidad"], 'meta_complejidad')

    # Cobertura
    df_cob = df_cobertura_filtrado[~df_cobertura_filtrado['NombreProyecto'].isin(PROYECTOS_EXCLUIR_COVERAGE)]
    base_cob = df_cob if config_na["incluir_na_cobertura"] else df_cob.dropna(subset=['coverage'])
    if not base_cob.empty:
        total = len(base_cob)
        cumplen = len(base_cob[base_cob['coverage'] >= cobertura_min])
        meta = metas['meta_cobertura']
        objetivo = redondear_hacia_arriba(total * (meta / 100))
        okr = redondear_hacia_arriba((cumplen / objetivo) * 100) if objetivo > 0 else 0
        okr_rows.append({
            'Métrica': 'Cobertura',
            'Total Componentes': total,
            'Meta Configurada (%)': meta,
            'Componentes Objetivo': objetivo,
            'Componentes Cumplen': cumplen,
            'Cumplimiento OKR (%)': okr,
            'Estado': '✅ Cumple' if okr >= 100 else '⚠️ No cumple'
        })

    return pd.DataFrame(okr_rows)

def calcular_bugs_historico(df_historico, celula, anio):
    bug_cols = ['bugs_blocker', 'bugs_critical', 'bugs_major', 'bugs_minor']
    df_cel = df_historico[
        (df_historico['Celula'] == celula) &
        (df_historico['Mes'].dt.year == anio)
    ].copy()

    if df_cel.empty:
        return pd.DataFrame()

    bug_cols_disp = [c for c in bug_cols if c in df_cel.columns]
    df_mes = (
        df_cel.groupby(df_cel['Mes'].dt.to_period('M'))[bug_cols_disp]
        .sum().reset_index()
    )
    df_mes['Mes'] = df_mes['Mes'].dt.to_timestamp()
    df_mes = df_mes.sort_values('Mes').reset_index(drop=True)
    df_mes['Total Bugs'] = df_mes[bug_cols_disp].sum(axis=1)
    df_mes['Mes'] = df_mes['Mes'].dt.strftime('%Y-%m')
    df_mes = df_mes.rename(columns={
        'bugs_blocker': 'Crítico', 'bugs_critical': 'Alto',
        'bugs_major': 'Medio', 'bugs_minor': 'Bajo'
    })
    cols = ['Mes'] + [c for c in ['Crítico', 'Alto', 'Medio', 'Bajo', 'Total Bugs'] if c in df_mes.columns]
    return df_mes[cols]

def calcular_detalle_componentes(df_mes, celula, parametros):
    umbral_conf = parametros["reliability_rating"].split(",")
    umbral_mant = parametros["sqale_rating"].split(",")
    umbral_comp = parametros["duplicated_lines_density"].split(",")
    cobertura_min = parametros["coverage_min"]

    df_cel = df_mes[df_mes['Celula'] == celula].copy()

    def fmt_rating(val, umbral):
        if pd.isna(val) or val is None or str(val).lower() in ['none', 'nan']:
            return 'N/A'
        return str(val)

    def fmt_cobertura(val):
        if pd.isna(val) or val is None:
            return 'N/A'
        return round(float(val), 2)

    rows = []
    for _, row in df_cel.iterrows():
        rows.append({
            'NombreProyecto': row['NombreProyecto'],
            'Confiabilidad': fmt_rating(row.get('reliability_rating'), umbral_conf),
            'Mantenibilidad': fmt_rating(row.get('sqale_rating'), umbral_mant),
            'Cobertura de pruebas unitarias': fmt_cobertura(row.get('coverage')),
            'Complejidad': fmt_rating(row.get('complexity'), umbral_comp),
            'Crítica': int(row.get('bugs_blocker', 0) or 0),
            'Alta': int(row.get('bugs_critical', 0) or 0),
            'Media': int(row.get('bugs_major', 0) or 0),
            'Baja': int(row.get('bugs_minor', 0) or 0),
            'Total Bugs': int((row.get('bugs_blocker', 0) or 0) +
                              (row.get('bugs_critical', 0) or 0) +
                              (row.get('bugs_major', 0) or 0) +
                              (row.get('bugs_minor', 0) or 0))
        })
    return pd.DataFrame(rows)

# ── GENERACION EXCEL ──────────────────────────────────────────
def generar_excel(celula, mes_str, df_okr, df_bugs, df_detalle):
    wb = Workbook()
    ws = wb.active
    ws.title = f"Reporte {mes_str}"

    # ── ESTILOS ───────────────────────────────────────────────
    verde_oscuro = "006633"
    verde_claro = "E8F5E9"
    verde_cumple = "d4edda"
    rojo_no_cumple = "f8d7da"
    gris_header = "F2F2F2"
    blanco = "FFFFFF"
    amarillo = "FFF3CD"

    def estilo_header_principal(cell, bg=verde_oscuro, font_color="FFFFFF"):
        cell.font = Font(bold=True, color=font_color, name='Arial', size=11)
        cell.fill = PatternFill("solid", fgColor=bg)
        cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)

    def estilo_header_col(cell):
        cell.font = Font(bold=True, color="FFFFFF", name='Arial', size=10)
        cell.fill = PatternFill("solid", fgColor=verde_oscuro)
        cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)

    def estilo_dato(cell, bg=blanco, bold=False, center=False):
        cell.font = Font(name='Arial', size=10, bold=bold)
        cell.fill = PatternFill("solid", fgColor=bg)
        cell.alignment = Alignment(
            horizontal='center' if center else 'left',
            vertical='center', wrap_text=True
        )

    def borde_fino():
        lado = Side(style='thin', color='CCCCCC')
        return Border(left=lado, right=lado, top=lado, bottom=lado)

    # ── SECCIÓN OKR (columnas A-G) ────────────────────────────
    # Título OKR
    ws.merge_cells('A1:G1')
    titulo_okr = ws['A1']
    titulo_okr.value = f"OKR {mes_str} — {celula}"
    estilo_header_principal(titulo_okr)

    # Headers OKR
    okr_headers = ['Métrica', 'Total Componentes', 'Meta Configurada (%)',
                   'Componentes Objetivo', 'Componentes Cumplen',
                   'Cumplimiento OKR (%)', 'Estado']
    for col_idx, header in enumerate(okr_headers, 1):
        cell = ws.cell(row=2, column=col_idx, value=header)
        estilo_header_col(cell)

    # Datos OKR
    for row_idx, (_, row) in enumerate(df_okr.iterrows(), 3):
        cumple = row['Estado'] == '✅ Cumple'
        bg = verde_cumple if cumple else rojo_no_cumple
        valores = [row['Métrica'], row['Total Componentes'],
                   f"{row['Meta Configurada (%)']:.0f}%",
                   row['Componentes Objetivo'], row['Componentes Cumplen'],
                   f"{row['Cumplimiento OKR (%)']:.0f}%", row['Estado']]
        for col_idx, val in enumerate(valores, 1):
            cell = ws.cell(row=row_idx, column=col_idx, value=val)
            estilo_dato(cell, bg=bg, center=(col_idx > 1))
            cell.border = borde_fino()

    fila_bugs_inicio = 3 + len(df_okr) + 2

    # ── SECCIÓN BUGS (columnas A-F) ───────────────────────────
    ws.merge_cells(f'A{fila_bugs_inicio}:F{fila_bugs_inicio}')
    titulo_bugs = ws[f'A{fila_bugs_inicio}']
    titulo_bugs.value = f"BUGS {celula}"
    estilo_header_principal(titulo_bugs)

    bugs_headers = list(df_bugs.columns)
    for col_idx, header in enumerate(bugs_headers, 1):
        cell = ws.cell(row=fila_bugs_inicio + 1, column=col_idx, value=header)
        estilo_header_col(cell)

    for row_idx, (_, row) in enumerate(df_bugs.iterrows(), fila_bugs_inicio + 2):
        for col_idx, val in enumerate(row, 1):
            cell = ws.cell(row=row_idx, column=col_idx, value=val)
            estilo_dato(cell, center=(col_idx > 1))
            cell.border = borde_fino()

    # ── SECCIÓN DETALLE COMPONENTES (columna I en adelante) ───
    col_inicio_detalle = 9  # Columna I

    # Título detalle
    col_fin_detalle = col_inicio_detalle + len(df_detalle.columns) - 1
    ws.merge_cells(
        start_row=1, start_column=col_inicio_detalle,
        end_row=1, end_column=col_fin_detalle
    )
    titulo_det = ws.cell(row=1, column=col_inicio_detalle,
                         value=f"Detalle Componente — {celula} — {mes_str}")
    estilo_header_principal(titulo_det)

    # Headers detalle
    for col_idx, header in enumerate(df_detalle.columns, col_inicio_detalle):
        cell = ws.cell(row=2, column=col_idx, value=header)
        estilo_header_col(cell)

    # Datos detalle
    umbral_conf = []  # se usan solo para colores
    for row_idx, (_, row) in enumerate(df_detalle.iterrows(), 3):
        for col_idx, (col_name, val) in enumerate(row.items(), col_inicio_detalle):
            cell = ws.cell(row=row_idx, column=col_idx, value=val)
            bg = blanco

            # Color por rating
            if col_name in ['Confiabilidad', 'Mantenibilidad', 'Complejidad']:
                if val == 'A':
                    bg = verde_cumple
                elif val in ['B', 'C']:
                    bg = amarillo
                elif val in ['D', 'E']:
                    bg = rojo_no_cumple

            # Color por cobertura
            if col_name == 'Cobertura de pruebas unitarias' and val != 'N/A':
                try:
                    pct = float(val)
                    bg = verde_cumple if pct >= 0.7 else (amarillo if pct >= 0.5 else rojo_no_cumple)
                except:
                    pass

            estilo_dato(cell, bg=bg, center=(col_name != 'NombreProyecto'))
            cell.border = borde_fino()

    # ── ANCHOS DE COLUMNA ────────────────────────────────────
    anchos = {
        1: 18, 2: 12, 3: 14, 4: 14, 5: 14, 6: 14, 7: 12,
        8: 3,  # separador
        9: 45, 10: 12, 11: 12, 12: 16, 13: 12,
        14: 8, 15: 8, 16: 8, 17: 8, 18: 10
    }
    for col, ancho in anchos.items():
        ws.column_dimensions[get_column_letter(col)].width = ancho

    # Altura de filas
    ws.row_dimensions[1].height = 30
    ws.row_dimensions[2].height = 40

    # ── GUARDAR ───────────────────────────────────────────────
    output = BytesIO()
    wb.save(output)
    output.seek(0)
    return output

# ── PÁGINA STREAMLIT ──────────────────────────────────────────
st.title("📊 Reporte Mensual por Célula")
st.markdown("Genera el reporte Excel mensual con OKR, Bugs y Detalle de Componentes.")

# Cargar datos
archivos = glob.glob(os.path.join(UPLOAD_DIR, "metricas_*.xlsx"))
if not archivos:
    st.warning("⚠️ No se encontraron archivos de métricas en la carpeta uploads.")
    st.stop()

meses_disponibles = sorted([
    os.path.basename(f).split("_")[1].replace(".xlsx", "")
    for f in archivos
], reverse=True)

seleccion_proyectos = cargar_seleccion()
parametros = cargar_parametros()
metas = cargar_metas()
config_metricas = cargar_configuracion_metricas()
config_na = cargar_configuracion_na()
df_historico = cargar_todos_los_datos()

# Obtener células disponibles
ultimo_archivo = os.path.join(UPLOAD_DIR, f"metricas_{meses_disponibles[0]}.xlsx")
df_ultimo = cargar_datos(ultimo_archivo)
celulas = sorted([
    c for c in df_ultimo['Celula'].unique()
    if c not in ['nan', 'obsoleta'] and pd.notna(c)
])

if not celulas:
    st.warning("⚠️ No hay células disponibles.")
    st.stop()

# ── SELECTORES ────────────────────────────────────────────────
col1, col2 = st.columns(2)
with col1:
    celula_sel = st.selectbox("📁 Selecciona la Célula", celulas)
with col2:
    mes_sel = st.selectbox("📅 Selecciona el Mes", meses_disponibles)

# Cargar datos del mes seleccionado
archivo_mes = os.path.join(UPLOAD_DIR, f"metricas_{mes_sel}.xlsx")
if not os.path.exists(archivo_mes):
    st.error(f"⚠️ No se encontró el archivo para {mes_sel}.")
    st.stop()

df_mes = cargar_datos(archivo_mes)

# Filtrar por célula
df_celula_mes = df_mes[df_mes['Celula'] == celula_sel].copy()

if df_celula_mes.empty:
    st.warning(f"⚠️ No hay datos para {celula_sel} en {mes_sel}.")
    st.stop()

# Filtrar cobertura
df_cob_filtrado = filtrar_por_metrica(
    df_mes, celula_sel, seleccion_proyectos,
    config_metricas["cobertura_usar_seleccionados"]
)

# Calcular secciones
df_okr = calcular_okr(df_celula_mes, df_cob_filtrado, parametros, metas, config_na)
anio_sel = int(mes_sel.split("-")[0])
df_bugs = calcular_bugs_historico(df_historico, celula_sel, anio_sel)
df_detalle = calcular_detalle_componentes(df_mes, celula_sel, parametros)

# ── PREVIEW ───────────────────────────────────────────────────
st.markdown("---")
st.subheader(f"📈 OKR — {celula_sel} — {mes_sel}")
if not df_okr.empty:
    def color_okr(row):
        if row['Estado'] == '✅ Cumple':
            return ['background-color: #d4edda'] * len(row)
        return ['background-color: #f8d7da'] * len(row)
    st.dataframe(df_okr.style.apply(color_okr, axis=1), use_container_width=True, hide_index=True)
else:
    st.info("No hay datos OKR disponibles.")

st.markdown("---")
st.subheader(f"🐞 Bugs — {celula_sel} — {anio_sel}")
if not df_bugs.empty:
    st.dataframe(df_bugs, use_container_width=True, hide_index=True)
else:
    st.info("No hay datos de bugs disponibles.")

st.markdown("---")
st.subheader(f"📋 Detalle Componentes — {celula_sel} — {mes_sel}")
if not df_detalle.empty:
    st.dataframe(df_detalle, use_container_width=True, hide_index=True)
else:
    st.info("No hay componentes disponibles.")

# ── DESCARGAR ─────────────────────────────────────────────────
st.markdown("---")
if not df_okr.empty and not df_detalle.empty:
    excel_bytes = generar_excel(celula_sel, mes_sel, df_okr, df_bugs, df_detalle)
    nombre_archivo = f"DeudaTecnica_{celula_sel.replace(' ', '_')}_{mes_sel}.xlsx"

    st.download_button(
        label=f"⬇️ Descargar Reporte Excel — {celula_sel} — {mes_sel}",
        data=excel_bytes,
        file_name=nombre_archivo,
        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        type="primary"
    )
else:
    st.warning("⚠️ No hay suficientes datos para generar el reporte.")