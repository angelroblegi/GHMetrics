using DeudaTecnicaSonar.Services;

var builder = WebApplication.CreateBuilder(args);


builder.Services.AddRazorPages();
builder.Services.AddScoped<MetricasService>();
builder.Services.AddScoped<ConfiguracionService>();
builder.Services.AddScoped<AuthService>();  
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromHours(8);
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
});

var app = builder.Build(); 


if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseSession();
app.UseMiddleware<DeudaTecnicaSonar.Services.AuthMiddleware>();
app.UseAuthorization();
app.MapRazorPages();
app.Run();