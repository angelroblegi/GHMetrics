﻿namespace DeudaTecnicaSonar.Models
{
    public class MetricaProyecto
    {
        public string NombreProyecto { get; set; }
        public string Celula { get; set; }
        public string SecurityRating { get; set; }
        public string ReliabilityRating { get; set; }
        public string SqaleRating { get; set; }
        public string DuplicatedLinesDensity { get; set; }
        public double? Coverage { get; set; }
        public double? Bugs { get; set; }
        public double? BugsBlocker { get; set; }
        public double? BugsCritical { get; set; }
        public double? BugsMajor { get; set; }
        public double? BugsMinor { get; set; }
        public double? BugsInfo { get; set; }
        public DateTime? Mes { get; set; }
    }
}
