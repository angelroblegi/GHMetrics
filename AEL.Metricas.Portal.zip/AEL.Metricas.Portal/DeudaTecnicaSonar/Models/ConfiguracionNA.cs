﻿namespace DeudaTecnicaSonar.Models
{
    public class ConfiguracionNA
    {
        public bool IncluirNaSeguridad { get; set; } = false;
        public bool IncluirNaConfiabilidad { get; set; } = false;
        public bool IncluirNaMantenibilidad { get; set; } = false;
        public bool IncluirNaCobertura { get; set; } = false;
        public bool IncluirNaComplejidad { get; set; } = false;
    }
}
