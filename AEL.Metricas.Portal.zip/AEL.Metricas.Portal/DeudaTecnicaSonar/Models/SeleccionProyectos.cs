﻿namespace DeudaTecnicaSonar.Models
{
    public class SeleccionProyectos
    {
        public string Celula { get; set; }
        public List<string> Proyectos { get; set; } = new();
    }
}