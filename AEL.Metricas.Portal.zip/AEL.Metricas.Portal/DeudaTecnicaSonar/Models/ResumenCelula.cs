﻿namespace DeudaTecnicaSonar.Models
{
    public class ResumenCelula
    {
        public string Celula { get; set; }
        public int Seguridad { get; set; }
        public int Confiabilidad { get; set; }
        public int Mantenibilidad { get; set; }
        public int Cobertura { get; set; }
        public int Complejidad { get; set; }
        public int TotalBugs { get; set; }
        public int Critica { get; set; }
        public int Alta { get; set; }
        public int Media { get; set; }
        public int Baja { get; set; }
    }
}
