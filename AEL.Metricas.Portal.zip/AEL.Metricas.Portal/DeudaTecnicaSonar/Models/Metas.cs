﻿namespace DeudaTecnicaSonar.Models
{
    public class Metas
    {
        public double MetaSeguridad { get; set; } = 90;
        public double MetaConfiabilidad { get; set; } = 90;
        public double MetaMantenibilidad { get; set; } = 90;
        public double MetaCobertura { get; set; } = 70;
        public double MetaComplejidad { get; set; } = 90;
    }
}
