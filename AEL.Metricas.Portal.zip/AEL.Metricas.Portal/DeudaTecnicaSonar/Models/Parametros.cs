﻿namespace DeudaTecnicaSonar.Models
{
    public class Parametros
    {
        public string SecurityRating { get; set; } = "A,B,C,D,E";
        public string ReliabilityRating { get; set; } = "A,B,C,D,E";
        public string SqaleRating { get; set; } = "A,B,C,D,E";
        public string DuplicatedLinesDensity { get; set; } = "A,B,C,D,E";
        public double CoverageMin { get; set; } = 0;
    }
}
