﻿namespace DeudaTecnicaSonar.Models
{
    public class OkrCumplimiento
    {
        public string Metrica { get; set; }
        public int TotalComponentes { get; set; }
        public double MetaConfigurada { get; set; }
        public int ComponentesObjetivo { get; set; }
        public int ComponentesCumplen { get; set; }
        public int CumplimientoOkr { get; set; }
        public bool Cumple => CumplimientoOkr >= 100;
    }

    public class ProgresoMetrica
    {
        public string Nombre { get; set; }
        public int Actual { get; set; }
        public int Meta { get; set; }
        public string Color { get; set; }
        public bool Cumple => Actual >= Meta;
    }

    public class ProyectoCobertura
    {
        public string Proyecto { get; set; }
        public string Cobertura { get; set; }
        public string Cumple { get; set; }
        public bool EsResumen { get; set; }
    }

    public class ComponenteDegradado
    {
        public string Componente { get; set; }
        public string ValorAnterior { get; set; }
        public string ValorActual { get; set; }
    }

    public class BugsMes
    {
        public string Mes { get; set; }
        public int TotalBugs { get; set; }
        public string FactorCrecimiento { get; set; }
        public string PorcentajeEliminacion { get; set; }
    }

    public class TendenciaMes
    {
        public string Mes { get; set; }
        public int CumplimientoOkr { get; set; }
    }
    public class TendenciaBugsCelula
    {
        public string Celula { get; set; }
        public List<TendenciaMes> Meses { get; set; } = new();
    }

    public class TendenciaCoberturaCelula
    {
        public string Celula { get; set; }
        public List<TendenciaMes> Meses { get; set; } = new();
    }
}