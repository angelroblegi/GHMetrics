﻿namespace DeudaTecnicaSonar.Models
{
    public class ConfiguracionMetricas
    {
        public bool SeguridadUsarSeleccionados { get; set; } = false;
        public bool ConfiabilidadUsarSeleccionados { get; set; } = false;
        public bool MantenibilidadUsarSeleccionados { get; set; } = false;
        public bool CoberturaUsarSeleccionados { get; set; } = true;
        public bool ComplejidadUsarSeleccionados { get; set; } = false;
    }
}
