﻿using DeudaTecnicaSonar.Models;
using DeudaTecnicaSonar.Services;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DeudaTecnicaSonar.Pages
{
    public class DetalleCelulaModel : PageModel
    {
        private readonly MetricasService _metricasService;
        private readonly ConfiguracionService _configService;

        public List<string> CelulasDisponibles { get; set; } = new();
        public List<string> AniosDisponibles { get; set; } = new();
        public List<string> MesesDelAnio { get; set; } = new();

        public string CelulaSeleccionada { get; set; }
        public string AnioSeleccionado { get; set; }
        public string MesSeleccionado { get; set; }
        public string MesAnterior { get; set; }
        public string Error { get; set; }

        public List<OkrCumplimiento> OkrData { get; set; } = new();
        public List<ProgresoMetrica> ProgresoMetricas { get; set; } = new();
        public List<MetricaProyecto> ProyectosTabla { get; set; } = new();
        public List<ProyectoCobertura> ProyectosCobertura { get; set; } = new();
        public List<ProyectoCobertura> ProyectosExcluidos { get; set; } = new();
        public Dictionary<string, List<ComponenteDegradado>> Degradados { get; set; } = new();
        public List<BugsMes> TendenciaBugs { get; set; } = new();
        public Dictionary<string, List<TendenciaMes>> TendenciasMetricas { get; set; } = new();

        public Parametros Parametros { get; set; } = new();
        public Metas Metas { get; set; } = new();

        private readonly List<string> _proyectosExcluirCoverage = new()
        {
            "AEL.DebidaDiligencia.FrontEnd:Quality",
            "AEL.NominaElectronica.FrontEnd:Quality"
        };

        public DetalleCelulaModel(MetricasService metricasService, ConfiguracionService configService)
        {
            _metricasService = metricasService;
            _configService = configService;
        }

        public void OnGet(string celula, string anio, string mes)
        {
            Parametros = _configService.CargarParametros();
            Metas = _configService.CargarMetas();
            var configNA = _configService.CargarConfiguracionNA();
            var configMetricas = _configService.CargarConfiguracionMetricas();
            var seleccion = _configService.CargarSeleccion() ?? new Dictionary<string, List<string>>();

            var todosLosProyectos = _metricasService.LeerTodosLosExcels();

            // Células disponibles
            CelulasDisponibles = todosLosProyectos
                .Where(p => !string.IsNullOrEmpty(p.Celula)
                    && p.Celula.ToLower() != "nan"
                    && p.Celula.ToLower() != "obsoleta")
                .Select(p => p.Celula)
                .Distinct().OrderBy(c => c).ToList();

            if (!CelulasDisponibles.Any()) { Error = "⚠️ No hay células disponibles."; return; }

            CelulaSeleccionada = string.IsNullOrEmpty(celula)
                ? CelulasDisponibles.First() : celula;

            // Años disponibles para la célula
            AniosDisponibles = todosLosProyectos
                .Where(p => p.Celula == CelulaSeleccionada && p.Mes.HasValue)
                .Select(p => p.Mes.Value.Year.ToString())
                .Distinct().OrderByDescending(a => a).ToList();

            if (!AniosDisponibles.Any()) { Error = "⚠️ No hay datos para esta célula."; return; }

            AnioSeleccionado = string.IsNullOrEmpty(anio) ? AniosDisponibles.First() : anio;

            // Meses disponibles para célula + año
            MesesDelAnio = todosLosProyectos
                .Where(p => p.Celula == CelulaSeleccionada
                    && p.Mes.HasValue
                    && p.Mes.Value.Year.ToString() == AnioSeleccionado)
                .Select(p => p.Mes.Value.ToString("yyyy-MM"))
                .Distinct().OrderByDescending(m => m).ToList();

            if (!MesesDelAnio.Any()) { Error = "⚠️ No hay meses disponibles para este año."; return; }

            MesSeleccionado = string.IsNullOrEmpty(mes) ? MesesDelAnio.First() : mes;

            // Proyectos del mes seleccionado
            var proyectosMes = todosLosProyectos
                .Where(p => p.Celula == CelulaSeleccionada
                    && p.Mes.HasValue
                    && p.Mes.Value.ToString("yyyy-MM") == MesSeleccionado)
                .ToList();

            if (!proyectosMes.Any()) { Error = $"⚠️ No hay datos para {MesSeleccionado}."; return; }

            var seleccionCelula = seleccion.ContainsKey(CelulaSeleccionada)
                ? seleccion[CelulaSeleccionada] : new List<string>();

            var umbralConfiabilidad = Parametros.ReliabilityRating.Split(',').ToList();
            var umbralMantenibilidad = Parametros.SqaleRating.Split(',').ToList();
            var umbralComplejidad = Parametros.DuplicatedLinesDensity.Split(',').ToList();

            var dfConfiabilidad = FiltrarPorMetrica(proyectosMes, seleccionCelula,
                configMetricas.ConfiabilidadUsarSeleccionados);
            var dfMantenibilidad = FiltrarPorMetrica(proyectosMes, seleccionCelula,
                configMetricas.MantenibilidadUsarSeleccionados);
            var dfComplejidad = FiltrarPorMetrica(proyectosMes, seleccionCelula,
                configMetricas.ComplejidadUsarSeleccionados);
            var dfCobertura = FiltrarPorMetrica(proyectosMes, seleccionCelula,
                configMetricas.CoberturaUsarSeleccionados)
                .Where(p => !_proyectosExcluirCoverage.Contains(p.NombreProyecto)).ToList();

            // OKR
            OkrData = CalcularOkr(dfConfiabilidad, dfMantenibilidad, dfComplejidad, dfCobertura,
                umbralConfiabilidad, umbralMantenibilidad, umbralComplejidad,
                configNA, Parametros, Metas);

            // Progreso
            ProgresoMetricas = CalcularProgreso(dfConfiabilidad, dfMantenibilidad,
                dfComplejidad, dfCobertura,
                umbralConfiabilidad, umbralMantenibilidad, umbralComplejidad,
                configNA, Parametros, Metas);

            // Tabla proyectos
            ProyectosTabla = proyectosMes;

            // Detalle cobertura
            var (incluidos, excluidos) = CalcularDetalleCobertura(
                proyectosMes, seleccionCelula,
                configMetricas.CoberturaUsarSeleccionados,
                configNA.IncluirNaCobertura,
                Parametros.CoverageMin);
            ProyectosCobertura = incluidos;
            ProyectosExcluidos = excluidos;

            // Componentes degradados - solo compara dentro del mismo año
            var mesesAnioOrdenados = MesesDelAnio.OrderBy(m => m).ToList();
            var indexMes = mesesAnioOrdenados.IndexOf(MesSeleccionado);
            if (indexMes > 0)
            {
                MesAnterior = mesesAnioOrdenados[indexMes - 1];
                var proyectosMesAnterior = todosLosProyectos
                    .Where(p => p.Celula == CelulaSeleccionada
                        && p.Mes.HasValue
                        && p.Mes.Value.ToString("yyyy-MM") == MesAnterior)
                    .ToList();

                Degradados = CalcularDegradados(
                    proyectosMesAnterior, proyectosMes,
                    seleccionCelula, configMetricas, configNA,
                    umbralConfiabilidad, umbralMantenibilidad, umbralComplejidad);
            }

            // Tendencia bugs - solo meses del año seleccionado
            TendenciaBugs = CalcularTendenciaBugs(
                todosLosProyectos, CelulaSeleccionada, AnioSeleccionado);

            // Tendencias métricas - solo meses del año seleccionado
            TendenciasMetricas = CalcularTendenciasMetricas(
                todosLosProyectos, CelulaSeleccionada, AnioSeleccionado,
                seleccionCelula, configMetricas, configNA,
                umbralConfiabilidad, umbralMantenibilidad, umbralComplejidad,
                Parametros, Metas);
        }

        // ── HELPERS ──────────────────────────────────────────────
        private List<MetricaProyecto> FiltrarPorMetrica(
            List<MetricaProyecto> proyectos,
            List<string> seleccionados, bool usarSeleccionados)
        {
            if (usarSeleccionados && seleccionados.Any())
                return proyectos.Where(p => seleccionados.Contains(p.NombreProyecto)).ToList();
            return proyectos;
        }

        private int RedondearArriba(double valor) => (int)(valor + 0.5);

        private List<OkrCumplimiento> CalcularOkr(
            List<MetricaProyecto> dfConf, List<MetricaProyecto> dfMant,
            List<MetricaProyecto> dfComp, List<MetricaProyecto> dfCob,
            List<string> umbralConf, List<string> umbralMant, List<string> umbralComp,
            ConfiguracionNA configNA, Parametros parametros, Metas metas)
        {
            var resultado = new List<OkrCumplimiento>();

            void Agregar(string nombre, List<MetricaProyecto> df,
                Func<MetricaProyecto, string> selector,
                List<string> umbral, bool incluirNA, double metaConf)
            {
                var base_ = incluirNA ? df : df.Where(p => selector(p) != null).ToList();
                if (!base_.Any()) return;
                var total = base_.Count;
                var cumplen = base_.Count(p => umbral.Contains(selector(p)));
                var objetivo = RedondearArriba(total * (metaConf / 100));
                var okr = objetivo > 0 ? RedondearArriba(cumplen * 100.0 / objetivo) : 0;
                resultado.Add(new OkrCumplimiento
                {
                    Metrica = nombre,
                    TotalComponentes = total,
                    MetaConfigurada = metaConf,
                    ComponentesObjetivo = objetivo,
                    ComponentesCumplen = cumplen,
                    CumplimientoOkr = okr
                });
            }

            Agregar("Confiabilidad", dfConf, p => p.ReliabilityRating,
                umbralConf, configNA.IncluirNaConfiabilidad, metas.MetaConfiabilidad);
            Agregar("Mantenibilidad", dfMant, p => p.SqaleRating,
                umbralMant, configNA.IncluirNaMantenibilidad, metas.MetaMantenibilidad);
            Agregar("Complejidad", dfComp, p => p.DuplicatedLinesDensity,
                umbralComp, configNA.IncluirNaComplejidad, metas.MetaComplejidad);

            var baseCob = configNA.IncluirNaCobertura
                ? dfCob : dfCob.Where(p => p.Coverage.HasValue).ToList();
            if (baseCob.Any())
            {
                var total = baseCob.Count;
                var cumplen = baseCob.Count(p => (p.Coverage ?? 0) >= parametros.CoverageMin);
                var objetivo = RedondearArriba(total * (metas.MetaCobertura / 100));
                var okr = objetivo > 0 ? RedondearArriba(cumplen * 100.0 / objetivo) : 0;
                resultado.Add(new OkrCumplimiento
                {
                    Metrica = "Cobertura",
                    TotalComponentes = total,
                    MetaConfigurada = metas.MetaCobertura,
                    ComponentesObjetivo = objetivo,
                    ComponentesCumplen = cumplen,
                    CumplimientoOkr = okr
                });
            }

            return resultado;
        }

        private List<ProgresoMetrica> CalcularProgreso(
            List<MetricaProyecto> dfConf, List<MetricaProyecto> dfMant,
            List<MetricaProyecto> dfComp, List<MetricaProyecto> dfCob,
            List<string> umbralConf, List<string> umbralMant, List<string> umbralComp,
            ConfiguracionNA configNA, Parametros parametros, Metas metas)
        {
            var resultado = new List<ProgresoMetrica>();

            void Agregar(string nombre, List<MetricaProyecto> df,
                Func<MetricaProyecto, string> selector,
                List<string> umbral, bool incluirNA,
                double metaConf, string color)
            {
                var base_ = incluirNA ? df : df.Where(p => selector(p) != null).ToList();
                if (!base_.Any()) return;
                var total = base_.Count;
                var cumplen = base_.Count(p => umbral.Contains(selector(p)));
                var objetivo = RedondearArriba(total * (metaConf / 100));
                var okr = objetivo > 0 ? RedondearArriba(cumplen * 100.0 / objetivo) : 0;
                resultado.Add(new ProgresoMetrica
                {
                    Nombre = nombre,
                    Actual = okr,
                    Meta = 100,
                    Color = color
                });
            }

            Agregar("Confiabilidad", dfConf, p => p.ReliabilityRating,
                umbralConf, configNA.IncluirNaConfiabilidad,
                metas.MetaConfiabilidad, "#ff7f0e");
            Agregar("Mantenibilidad", dfMant, p => p.SqaleRating,
                umbralMant, configNA.IncluirNaMantenibilidad,
                metas.MetaMantenibilidad, "#2ca02c");

            var baseCob = configNA.IncluirNaCobertura
                ? dfCob : dfCob.Where(p => p.Coverage.HasValue).ToList();
            if (baseCob.Any())
            {
                var total = baseCob.Count;
                var cumplen = baseCob.Count(p => (p.Coverage ?? 0) >= parametros.CoverageMin);
                var objetivo = RedondearArriba(total * (metas.MetaCobertura / 100));
                var okr = objetivo > 0 ? RedondearArriba(cumplen * 100.0 / objetivo) : 0;
                resultado.Add(new ProgresoMetrica
                {
                    Nombre = "Cobertura",
                    Actual = okr,
                    Meta = 100,
                    Color = "#d62728"
                });
            }

            Agregar("Complejidad", dfComp, p => p.DuplicatedLinesDensity,
                umbralComp, configNA.IncluirNaComplejidad,
                metas.MetaComplejidad, "#9467bd");

            return resultado;
        }

        private (List<ProyectoCobertura>, List<ProyectoCobertura>) CalcularDetalleCobertura(
            List<MetricaProyecto> proyectos, List<string> seleccionados,
            bool usarSeleccionados, bool incluirNA, double coberturaMin)
        {
            var incluidos = new List<ProyectoCobertura>();
            var excluidos = new List<ProyectoCobertura>();

            var base_ = usarSeleccionados && seleccionados.Any()
                ? proyectos.Where(p => seleccionados.Contains(p.NombreProyecto)).ToList()
                : proyectos.Where(p => p.Coverage.HasValue).ToList();

            var incluir = base_.Where(p => !_proyectosExcluirCoverage.Contains(p.NombreProyecto)).ToList();
            var excluir = base_.Where(p => _proyectosExcluirCoverage.Contains(p.NombreProyecto)).ToList();

            foreach (var p in incluir)
            {
                incluidos.Add(new ProyectoCobertura
                {
                    Proyecto = p.NombreProyecto,
                    Cobertura = p.Coverage.HasValue ? $"{p.Coverage:F0}%" : "N/A",
                    Cumple = p.Coverage.HasValue
                        ? (p.Coverage >= coberturaMin ? "✅" : "❌") : "N/A"
                });
            }

            if (incluidos.Any())
            {
                var conDatos = incluidos.Where(p => p.Cumple != "N/A").ToList();
                var queLosCumplen = conDatos.Count(p => p.Cumple == "✅");
                var promedio = incluir.Where(p => p.Coverage.HasValue)
                    .Select(p => p.Coverage.Value).DefaultIfEmpty(0).Average();
                var pct = conDatos.Any()
                    ? RedondearArriba(queLosCumplen * 100.0 / conDatos.Count) : 0;

                incluidos.Add(new ProyectoCobertura
                {
                    Proyecto = "Cumplimiento (%)",
                    Cobertura = $"{pct}%",
                    Cumple = $"{queLosCumplen}/{conDatos.Count}",
                    EsResumen = true
                });
                incluidos.Add(new ProyectoCobertura
                {
                    Proyecto = "Promedio Cobertura",
                    Cobertura = $"{RedondearArriba(promedio)}%",
                    Cumple = "",
                    EsResumen = true
                });
            }

            foreach (var p in excluir)
            {
                excluidos.Add(new ProyectoCobertura
                {
                    Proyecto = p.NombreProyecto,
                    Cobertura = p.Coverage.HasValue ? $"{p.Coverage:F0}%" : "N/A",
                    Cumple = "Excluido"
                });
            }

            return (incluidos, excluidos);
        }

        private Dictionary<string, List<ComponenteDegradado>> CalcularDegradados(
            List<MetricaProyecto> anterior, List<MetricaProyecto> actual,
            List<string> seleccionados, ConfiguracionMetricas configMetricas,
            ConfiguracionNA configNA,
            List<string> umbralConf, List<string> umbralMant, List<string> umbralComp)
        {
            var resultado = new Dictionary<string, List<ComponenteDegradado>>();

            void Analizar(string nombre, Func<MetricaProyecto, string> selector,
                List<string> umbral, bool usarSel, bool incluirNA)
            {
                var ant = FiltrarPorMetrica(anterior, seleccionados, usarSel);
                var act = FiltrarPorMetrica(actual, seleccionados, usarSel);

                if (!incluirNA)
                {
                    ant = ant.Where(p => selector(p) != null).ToList();
                    act = act.Where(p => selector(p) != null).ToList();
                }

                var dictAnt = ant.ToDictionary(p => p.NombreProyecto, p => selector(p));
                var dictAct = act.ToDictionary(p => p.NombreProyecto, p => selector(p));

                var degradados = dictAnt
                    .Where(kvp => dictAct.ContainsKey(kvp.Key)
                        && umbral.Contains(kvp.Value)
                        && !umbral.Contains(dictAct[kvp.Key]))
                    .Select(kvp => new ComponenteDegradado
                    {
                        Componente = kvp.Key,
                        ValorAnterior = kvp.Value ?? "N/A",
                        ValorActual = dictAct[kvp.Key] ?? "N/A"
                    }).ToList();

                resultado[nombre] = degradados;
            }

            Analizar("Confiabilidad", p => p.ReliabilityRating,
                umbralConf, configMetricas.ConfiabilidadUsarSeleccionados,
                configNA.IncluirNaConfiabilidad);
            Analizar("Mantenibilidad", p => p.SqaleRating,
                umbralMant, configMetricas.MantenibilidadUsarSeleccionados,
                configNA.IncluirNaMantenibilidad);
            Analizar("Complejidad", p => p.DuplicatedLinesDensity,
                umbralComp, configMetricas.ComplejidadUsarSeleccionados,
                configNA.IncluirNaComplejidad);

            return resultado;
        }

        private List<BugsMes> CalcularTendenciaBugs(
            List<MetricaProyecto> todos, string celula, string anio)
        {
            // Solo meses del año seleccionado
            var porMes = todos
                .Where(p => p.Celula == celula
                    && p.Mes.HasValue
                    && p.Mes.Value.Year.ToString() == anio)
                .GroupBy(p => p.Mes.Value.ToString("yyyy-MM"))
                .Select(g => new
                {
                    Mes = g.Key,
                    Total = (int)g.Sum(p =>
                        (p.BugsBlocker ?? 0) + (p.BugsCritical ?? 0) +
                        (p.BugsMajor ?? 0) + (p.BugsMinor ?? 0))
                })
                .OrderBy(x => x.Mes)
                .ToList();

            if (!porMes.Any()) return new List<BugsMes>();

            // Línea base = primer mes del año con datos
            var mesBase = porMes.First();
            int baseTotal = mesBase.Total;

            var resultado = new List<BugsMes>();
            for (int i = 0; i < porMes.Count; i++)
            {
                // Factor de crecimiento respecto al mes anterior dentro del año
                string factor = i == 0 ? "Base" :
                    $"{(porMes[i].Total - porMes[i - 1].Total):+#;-#;0}";

                // % eliminación respecto al primer mes del año
                string eliminacion = i == 0 ? "Base" :
                    baseTotal > 0
                        ? $"{RedondearArriba((baseTotal - porMes[i].Total) * 100.0 / baseTotal)}%"
                        : "N/A";

                resultado.Add(new BugsMes
                {
                    Mes = porMes[i].Mes,
                    TotalBugs = porMes[i].Total,
                    FactorCrecimiento = factor,
                    PorcentajeEliminacion = eliminacion
                });
            }

            return resultado;
        }

        private Dictionary<string, List<TendenciaMes>> CalcularTendenciasMetricas(
            List<MetricaProyecto> todos, string celula, string anio,
            List<string> seleccionados, ConfiguracionMetricas configMetricas,
            ConfiguracionNA configNA,
            List<string> umbralConf, List<string> umbralMant, List<string> umbralComp,
            Parametros parametros, Metas metas)
        {
            var resultado = new Dictionary<string, List<TendenciaMes>>();

            // Solo meses del año seleccionado
            var mesesAnio = todos
                .Where(p => p.Celula == celula
                    && p.Mes.HasValue
                    && p.Mes.Value.Year.ToString() == anio)
                .Select(p => p.Mes.Value.ToString("yyyy-MM"))
                .Distinct().OrderBy(m => m).ToList();

            void CalcularTendencia(string nombre,
                Func<MetricaProyecto, string> selector,
                List<string> umbral, bool usarSel, bool incluirNA, double metaConf)
            {
                var tendencia = new List<TendenciaMes>();
                foreach (var mes in mesesAnio)
                {
                    var df = todos.Where(p => p.Celula == celula
                        && p.Mes.HasValue
                        && p.Mes.Value.ToString("yyyy-MM") == mes).ToList();

                    df = FiltrarPorMetrica(df, seleccionados, usarSel);
                    if (!incluirNA) df = df.Where(p => selector(p) != null).ToList();
                    if (!df.Any()) continue;

                    var total = df.Count;
                    var cumplen = df.Count(p => umbral.Contains(selector(p)));
                    var objetivo = RedondearArriba(total * (metaConf / 100));
                    var okr = objetivo > 0 ? RedondearArriba(cumplen * 100.0 / objetivo) : 0;
                    tendencia.Add(new TendenciaMes { Mes = mes, CumplimientoOkr = okr });
                }
                if (tendencia.Any()) resultado[nombre] = tendencia;
            }

            CalcularTendencia("Confiabilidad", p => p.ReliabilityRating,
                umbralConf, configMetricas.ConfiabilidadUsarSeleccionados,
                configNA.IncluirNaConfiabilidad, metas.MetaConfiabilidad);
            CalcularTendencia("Mantenibilidad", p => p.SqaleRating,
                umbralMant, configMetricas.MantenibilidadUsarSeleccionados,
                configNA.IncluirNaMantenibilidad, metas.MetaMantenibilidad);
            CalcularTendencia("Complejidad", p => p.DuplicatedLinesDensity,
                umbralComp, configMetricas.ComplejidadUsarSeleccionados,
                configNA.IncluirNaComplejidad, metas.MetaComplejidad);

            // Cobertura
            var tendenciaCob = new List<TendenciaMes>();
            foreach (var mes in mesesAnio)
            {
                var df = todos.Where(p => p.Celula == celula
                    && p.Mes.HasValue
                    && p.Mes.Value.ToString("yyyy-MM") == mes).ToList();

                df = FiltrarPorMetrica(df, seleccionados,
                    configMetricas.CoberturaUsarSeleccionados);
                df = df.Where(p => !_proyectosExcluirCoverage.Contains(p.NombreProyecto)).ToList();
                if (!configNA.IncluirNaCobertura)
                    df = df.Where(p => p.Coverage.HasValue).ToList();
                if (!df.Any()) continue;

                var total = df.Count;
                var cumplen = df.Count(p => (p.Coverage ?? 0) >= parametros.CoverageMin);
                var objetivo = RedondearArriba(total * (metas.MetaCobertura / 100));
                var okr = objetivo > 0 ? RedondearArriba(cumplen * 100.0 / objetivo) : 0;
                tendenciaCob.Add(new TendenciaMes { Mes = mes, CumplimientoOkr = okr });
            }
            if (tendenciaCob.Any()) resultado["Cobertura"] = tendenciaCob;

            return resultado;
        }
    }
}