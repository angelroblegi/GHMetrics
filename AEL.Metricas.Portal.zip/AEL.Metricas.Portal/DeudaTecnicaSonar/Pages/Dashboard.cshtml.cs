﻿using DeudaTecnicaSonar.Models;
using DeudaTecnicaSonar.Services;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DeudaTecnicaSonar.Pages
{
    public class DashboardModel : PageModel
    {
        private readonly MetricasService _metricasService;
        private readonly ConfiguracionService _configService;

        public List<string> MesesDisponibles { get; set; } = new();
        public string MesSeleccionado { get; set; }
        public string AnioActual { get; set; }
        public List<ResumenCelula> Resumenes { get; set; } = new();
        public Parametros Parametros { get; set; } = new();
        public Metas Metas { get; set; } = new();
        public string Error { get; set; }

        // Tendencias
        public List<string> MesesDelAnio { get; set; } = new();
        public List<TendenciaBugsCelula> TendenciaBugs { get; set; } = new();
        public List<TendenciaCoberturaCelula> TendenciaCobertura { get; set; } = new();

        private readonly List<string> _proyectosExcluirCoverage = new()
        {
            "AEL.DebidaDiligencia.FrontEnd:Quality",
            "AEL.NominaElectronica.FrontEnd:Quality"
        };

        public DashboardModel(MetricasService metricasService,
            ConfiguracionService configService)
        {
            _metricasService = metricasService;
            _configService = configService;
        }

        public void OnGet(string mes)
        {
            Parametros = _configService.CargarParametros();
            Metas = _configService.CargarMetas();
            var configNA = _configService.CargarConfiguracionNA();
            var configMetricas = _configService.CargarConfiguracionMetricas();
            var seleccion = _configService.CargarSeleccion();

            MesesDisponibles = _metricasService.ObtenerMesesDisponibles();

            if (!MesesDisponibles.Any())
            {
                Error = "⚠️ No hay archivos de métricas. Ve a 'Subir Excel' primero.";
                return;
            }

            MesSeleccionado = string.IsNullOrEmpty(mes)
                ? MesesDisponibles.First() : mes;

            AnioActual = DateTime.Now.Year.ToString();

            if (seleccion == null || !seleccion.Any())
            {
                Error = "⚠️ No hay proyectos seleccionados. Ve a 'Seleccionar Proyectos' primero.";
                return;
            }

            var ruta = _metricasService.ObtenerRutaArchivo(MesSeleccionado);
            if (!System.IO.File.Exists(ruta))
            {
                Error = $"⚠️ No se encontró el archivo para {MesSeleccionado}.";
                return;
            }

            var proyectos = _metricasService.LeerExcel(ruta);
            Resumenes = _metricasService.CalcularResumen(
                proyectos, Parametros, configNA, configMetricas, seleccion);

            // Meses del año actual disponibles
            MesesDelAnio = MesesDisponibles
                .Where(m => m.StartsWith(AnioActual))
                .OrderBy(m => m)
                .ToList();

            if (MesesDelAnio.Any())
            {
                var todosLosProyectos = _metricasService.LeerTodosLosExcels();
                var celulas = seleccion.Keys.ToList();

                TendenciaBugs = CalcularTendenciaBugs(
                    todosLosProyectos, celulas, AnioActual);

                TendenciaCobertura = CalcularTendenciaCobertura(
                    todosLosProyectos, celulas, AnioActual,
                    seleccion, configMetricas.CoberturaUsarSeleccionados,
                    configNA.IncluirNaCobertura, Parametros.CoverageMin);
            }
        }

        private List<TendenciaBugsCelula> CalcularTendenciaBugs(
            List<MetricaProyecto> todos,
            List<string> celulas,
            string anio)
        {
            var resultado = new List<TendenciaBugsCelula>();

            foreach (var celula in celulas)
            {
                var meses = todos
                    .Where(p => p.Celula == celula
                        && p.Mes.HasValue
                        && p.Mes.Value.Year.ToString() == anio)
                    .GroupBy(p => p.Mes.Value.ToString("yyyy-MM"))
                    .Select(g => new TendenciaMes
                    {
                        Mes = g.Key,
                        CumplimientoOkr = (int)g.Sum(p =>
                            (p.BugsBlocker ?? 0) + (p.BugsCritical ?? 0) +
                            (p.BugsMajor ?? 0) + (p.BugsMinor ?? 0))
                    })
                    .OrderBy(m => m.Mes)
                    .ToList();

                if (meses.Any())
                    resultado.Add(new TendenciaBugsCelula
                    {
                        Celula = celula,
                        Meses = meses
                    });
            }

            return resultado;
        }

        private List<TendenciaCoberturaCelula> CalcularTendenciaCobertura(
            List<MetricaProyecto> todos,
            List<string> celulas,
            string anio,
            Dictionary<string, List<string>> seleccion,
            bool usarSeleccionados,
            bool incluirNA,
            double coberturaMin)
        {
            var resultado = new List<TendenciaCoberturaCelula>();

            var mesesAnio = todos
                .Where(p => p.Mes.HasValue
                    && p.Mes.Value.Year.ToString() == anio)
                .Select(p => p.Mes.Value.ToString("yyyy-MM"))
                .Distinct().OrderBy(m => m).ToList();

            foreach (var celula in celulas)
            {
                var seleccionados = seleccion.ContainsKey(celula)
                    ? seleccion[celula] : new List<string>();

                var tendencia = new List<TendenciaMes>();

                foreach (var mes in mesesAnio)
                {
                    var df = todos.Where(p => p.Celula == celula
                        && p.Mes.HasValue
                        && p.Mes.Value.ToString("yyyy-MM") == mes).ToList();

                    if (usarSeleccionados && seleccionados.Any())
                        df = df.Where(p => seleccionados.Contains(p.NombreProyecto)).ToList();

                    df = df.Where(p => !_proyectosExcluirCoverage.Contains(p.NombreProyecto)).ToList();

                    if (!incluirNA)
                        df = df.Where(p => p.Coverage.HasValue).ToList();

                    if (!df.Any()) continue;

                    var total = df.Count;
                    var cumplen = df.Count(p => (p.Coverage ?? 0) >= coberturaMin);
                    var pct = (int)((double)cumplen / total * 100 + 0.5);

                    tendencia.Add(new TendenciaMes { Mes = mes, CumplimientoOkr = pct });
                }

                if (tendencia.Any())
                    resultado.Add(new TendenciaCoberturaCelula
                    {
                        Celula = celula,
                        Meses = tendencia
                    });
            }

            return resultado;
        }
    }
}