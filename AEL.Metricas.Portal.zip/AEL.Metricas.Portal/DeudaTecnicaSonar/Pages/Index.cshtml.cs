using DeudaTecnicaSonar.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DeudaTecnicaSonar.Pages
{
    public class IndexModel : PageModel
    {
        private readonly AuthService _authService;

        public string Error { get; set; }

        public IndexModel(AuthService authService)
        {
            _authService = authService;
        }

        public IActionResult OnGet()
        {
            // Si ya est� logueado redirigir seg�n rol
            var rol = HttpContext.Session.GetString("Rol");
            if (!string.IsNullOrEmpty(rol))
            {
                return rol == "admin"
                    ? RedirectToPage("/Dashboard")
                    : RedirectToPage("/DetalleCelula");
            }
            return Page();
        }

        public IActionResult OnPost(string usuario, string contrasena)
        {
            var user = _authService.Autenticar(usuario, contrasena);
            if (user == null)
            {
                Error = "Usuario o contrase�a incorrectos.";
                return Page();
            }

            HttpContext.Session.SetString("Usuario", user.NombreUsuario);
            HttpContext.Session.SetString("Rol", user.Rol);

            return user.Rol == "admin"
                ? RedirectToPage("/Dashboard")
                : RedirectToPage("/DetalleCelula");
        }
        [ValidateAntiForgeryToken]
        public IActionResult OnPostLogout()
        {
            HttpContext.Session.Clear();
            return RedirectToPage("/Index");
        }
    }
}