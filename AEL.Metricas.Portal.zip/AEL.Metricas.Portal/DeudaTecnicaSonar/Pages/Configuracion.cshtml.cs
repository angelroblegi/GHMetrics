﻿using DeudaTecnicaSonar.Models;
using DeudaTecnicaSonar.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DeudaTecnicaSonar.Pages
{
    public class ConfiguracionModel : PageModel
    {
        private readonly ConfiguracionService _configService;

        public Parametros Parametros { get; set; } = new();
        public Metas Metas { get; set; } = new();
        public ConfiguracionNA ConfigNA { get; set; } = new();
        public ConfiguracionMetricas ConfigMetricas { get; set; } = new();
        public string Mensaje { get; set; }
        public bool Exito { get; set; }

        public ConfiguracionModel(ConfiguracionService configService)
        {
            _configService = configService;
        }

        public void OnGet()
        {
            Parametros = _configService.CargarParametros();
            Metas = _configService.CargarMetas();
            ConfigNA = _configService.CargarConfiguracionNA();
            ConfigMetricas = _configService.CargarConfiguracionMetricas();
        }

        public IActionResult OnPost(
            bool SecurityRating_A, bool SecurityRating_B, bool SecurityRating_C,
            bool SecurityRating_D, bool SecurityRating_E,
            bool ReliabilityRating_A, bool ReliabilityRating_B, bool ReliabilityRating_C,
            bool ReliabilityRating_D, bool ReliabilityRating_E,
            bool SqaleRating_A, bool SqaleRating_B, bool SqaleRating_C,
            bool SqaleRating_D, bool SqaleRating_E,
            bool DuplicatedLinesDensity_A, bool DuplicatedLinesDensity_B,
            bool DuplicatedLinesDensity_C, bool DuplicatedLinesDensity_D,
            bool DuplicatedLinesDensity_E,
            double CoverageMin,
            double MetaSeguridad, double MetaConfiabilidad,
            double MetaMantenibilidad, double MetaCobertura, double MetaComplejidad,
            bool IncluirNaSeguridad, bool IncluirNaConfiabilidad,
            bool IncluirNaMantenibilidad, bool IncluirNaCobertura, bool IncluirNaComplejidad,
            bool SeguridadUsarSeleccionados, bool ConfiabilidadUsarSeleccionados,
            bool MantenibilidadUsarSeleccionados, bool CoberturaUsarSeleccionados,
            bool ComplejidadUsarSeleccionados)
        {
            // Construir strings solo con las letras seleccionadas
            var seguridad = new List<string>();
            if (SecurityRating_A) seguridad.Add("A");
            if (SecurityRating_B) seguridad.Add("B");
            if (SecurityRating_C) seguridad.Add("C");
            if (SecurityRating_D) seguridad.Add("D");
            if (SecurityRating_E) seguridad.Add("E");

            var confiabilidad = new List<string>();
            if (ReliabilityRating_A) confiabilidad.Add("A");
            if (ReliabilityRating_B) confiabilidad.Add("B");
            if (ReliabilityRating_C) confiabilidad.Add("C");
            if (ReliabilityRating_D) confiabilidad.Add("D");
            if (ReliabilityRating_E) confiabilidad.Add("E");

            var mantenibilidad = new List<string>();
            if (SqaleRating_A) mantenibilidad.Add("A");
            if (SqaleRating_B) mantenibilidad.Add("B");
            if (SqaleRating_C) mantenibilidad.Add("C");
            if (SqaleRating_D) mantenibilidad.Add("D");
            if (SqaleRating_E) mantenibilidad.Add("E");

            var complejidad = new List<string>();
            if (DuplicatedLinesDensity_A) complejidad.Add("A");
            if (DuplicatedLinesDensity_B) complejidad.Add("B");
            if (DuplicatedLinesDensity_C) complejidad.Add("C");
            if (DuplicatedLinesDensity_D) complejidad.Add("D");
            if (DuplicatedLinesDensity_E) complejidad.Add("E");

            _configService.GuardarParametros(new Parametros
            {
                SecurityRating = seguridad.Any() ? string.Join(",", seguridad) : "A",
                ReliabilityRating = confiabilidad.Any() ? string.Join(",", confiabilidad) : "A",
                SqaleRating = mantenibilidad.Any() ? string.Join(",", mantenibilidad) : "A",
                DuplicatedLinesDensity = complejidad.Any() ? string.Join(",", complejidad) : "A",
                CoverageMin = CoverageMin
            });

            _configService.GuardarMetas(new Metas
            {
                MetaSeguridad = MetaSeguridad,
                MetaConfiabilidad = MetaConfiabilidad,
                MetaMantenibilidad = MetaMantenibilidad,
                MetaCobertura = MetaCobertura,
                MetaComplejidad = MetaComplejidad
            });

            _configService.GuardarConfiguracionNA(new ConfiguracionNA
            {
                IncluirNaSeguridad = IncluirNaSeguridad,
                IncluirNaConfiabilidad = IncluirNaConfiabilidad,
                IncluirNaMantenibilidad = IncluirNaMantenibilidad,
                IncluirNaCobertura = IncluirNaCobertura,
                IncluirNaComplejidad = IncluirNaComplejidad
            });

            _configService.GuardarConfiguracionMetricas(new ConfiguracionMetricas
            {
                SeguridadUsarSeleccionados = SeguridadUsarSeleccionados,
                ConfiabilidadUsarSeleccionados = ConfiabilidadUsarSeleccionados,
                MantenibilidadUsarSeleccionados = MantenibilidadUsarSeleccionados,
                CoberturaUsarSeleccionados = CoberturaUsarSeleccionados,
                ComplejidadUsarSeleccionados = ComplejidadUsarSeleccionados
            });

            Parametros = _configService.CargarParametros();
            Metas = _configService.CargarMetas();
            ConfigNA = _configService.CargarConfiguracionNA();
            ConfigMetricas = _configService.CargarConfiguracionMetricas();

            Mensaje = "✅ Configuración guardada correctamente.";
            Exito = true;

            return Page();
        }
    }
}