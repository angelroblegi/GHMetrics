﻿using DeudaTecnicaSonar.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DeudaTecnicaSonar.Pages
{
    public class UploadModel : PageModel
    {
        private readonly MetricasService _metricasService;
        private readonly IWebHostEnvironment _env;

        public string Mensaje { get; set; }
        public bool Exito { get; set; }
        public List<string> MesesDisponibles { get; set; } = new();

        public UploadModel(MetricasService metricasService, IWebHostEnvironment env)
        {
            _metricasService = metricasService;
            _env = env;
        }

        public void OnGet()
        {
            MesesDisponibles = _metricasService.ObtenerMesesDisponibles();
        }

        [ValidateAntiForgeryToken]
        public async Task<IActionResult> OnPostAsync(IFormFile archivo)
        {
            MesesDisponibles = _metricasService.ObtenerMesesDisponibles();

            if (archivo == null || archivo.Length == 0)
            {
                Mensaje = "⚠️ Por favor selecciona un archivo.";
                Exito = false;
                return Page();
            }

            var nombre = archivo.FileName;

            if (!nombre.StartsWith("metricas_") || !nombre.EndsWith(".xlsx"))
            {
                Mensaje = "⚠️ El archivo debe llamarse metricas_YYYY-MM.xlsx";
                Exito = false;
                return Page();
            }

            var uploadsPath = Path.Combine(_env.ContentRootPath, "Uploads");
            Directory.CreateDirectory(uploadsPath);
            var rutaDestino = Path.Combine(uploadsPath, nombre);

            using (var stream = new FileStream(rutaDestino, FileMode.Create))
            {
                await archivo.CopyToAsync(stream);
            }

            MesesDisponibles = _metricasService.ObtenerMesesDisponibles();
            Mensaje = $"✅ Archivo {nombre} subido correctamente.";
            Exito = true;

            return Page();
        }
    }
}