﻿using ClosedXML.Excel;
using DeudaTecnicaSonar.Models;
using DeudaTecnicaSonar.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DeudaTecnicaSonar.Pages
{
    public class InventarioModel : PageModel
    {
        private readonly MetricasService _metricasService;

        public List<MetricaProyecto> Proyectos { get; set; } = new();
        public List<string> Celulas { get; set; } = new();
        public string CelulaFiltro { get; set; }
        public string UltimoMes { get; set; }
        public string Error { get; set; }

        public InventarioModel(MetricasService metricasService)
        {
            _metricasService = metricasService;
        }

        public void OnGet(string celula)
        {
            var meses = _metricasService.ObtenerMesesDisponibles();
            if (!meses.Any())
            {
                Error = "⚠️ No hay archivos de métricas disponibles.";
                return;
            }

            UltimoMes = meses.First();
            var ruta = _metricasService.ObtenerRutaArchivo(UltimoMes);
            var todos = _metricasService.LeerExcel(ruta)
                .Where(p => !string.IsNullOrEmpty(p.Celula)
                    && p.Celula.ToLower() != "nan"
                    && p.Celula.ToLower() != "obsoleta")
                .ToList();

            Celulas = todos.Select(p => p.Celula).Distinct().OrderBy(c => c).ToList();
            CelulaFiltro = celula;

            Proyectos = string.IsNullOrEmpty(celula)
                ? todos.OrderBy(p => p.Celula).ThenBy(p => p.NombreProyecto).ToList()
                : todos.Where(p => p.Celula == celula)
                       .OrderBy(p => p.NombreProyecto).ToList();
        }

        public IActionResult OnGetDescargar(string celula)
        {
            var meses = _metricasService.ObtenerMesesDisponibles();
            if (!meses.Any()) return RedirectToPage();

            var ruta = _metricasService.ObtenerRutaArchivo(meses.First());
            var todos = _metricasService.LeerExcel(ruta)
                .Where(p => !string.IsNullOrEmpty(p.Celula)
                    && p.Celula.ToLower() != "nan"
                    && p.Celula.ToLower() != "obsoleta")
                .ToList();

            var datos = string.IsNullOrEmpty(celula)
                ? todos.OrderBy(p => p.Celula).ThenBy(p => p.NombreProyecto).ToList()
                : todos.Where(p => p.Celula == celula)
                       .OrderBy(p => p.NombreProyecto).ToList();

            using var workbook = new XLWorkbook();
            var sheet = workbook.Worksheets.Add("Inventario");

            // Encabezados
            sheet.Cell(1, 1).Value = "Célula";
            sheet.Cell(1, 2).Value = "NombreProyecto";

            // Estilo encabezados
            var headerRange = sheet.Range(1, 1, 1, 2);
            headerRange.Style.Font.Bold = true;
            headerRange.Style.Fill.BackgroundColor = XLColor.FromHtml("#006633");
            headerRange.Style.Font.FontColor = XLColor.White;
            headerRange.Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;

            // Datos
            for (int i = 0; i < datos.Count; i++)
            {
                sheet.Cell(i + 2, 1).Value = datos[i].Celula;
                sheet.Cell(i + 2, 2).Value = datos[i].NombreProyecto;

                // Filas alternas
                if (i % 2 == 0)
                {
                    sheet.Range(i + 2, 1, i + 2, 2)
                        .Style.Fill.BackgroundColor = XLColor.FromHtml("#f0f9f4");
                }
            }

            // Fila de total
            var totalRow = datos.Count + 2;
            sheet.Cell(totalRow, 1).Value = "Total";
            sheet.Cell(totalRow, 2).Value = datos.Count;
            sheet.Range(totalRow, 1, totalRow, 2).Style.Font.Bold = true;
            sheet.Range(totalRow, 1, totalRow, 2)
                .Style.Fill.BackgroundColor = XLColor.FromHtml("#d4edda");

            // Ajustar columnas
            sheet.Columns().AdjustToContents();

            using var stream = new MemoryStream();
            workbook.SaveAs(stream);
            stream.Seek(0, SeekOrigin.Begin);

            var nombreArchivo = string.IsNullOrEmpty(celula)
                ? $"inventario_completo_{meses.First()}.xlsx"
                : $"inventario_{celula}_{meses.First()}.xlsx";

            return File(stream.ToArray(),
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                nombreArchivo);
        }
    }
}