﻿using DeudaTecnicaSonar.Models;
using DeudaTecnicaSonar.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DeudaTecnicaSonar.Pages
{
    public class SeleccionProyectosModel : PageModel
    {
        private readonly MetricasService _metricasService;
        private readonly ConfiguracionService _configService;

        public List<string> MesesDisponibles { get; set; } = new();
        public string MesSeleccionado { get; set; }
        public List<string> TodasLasCelulas { get; set; } = new();
        public Dictionary<string, List<string>> ProyectosPorCelula { get; set; } = new();
        public Dictionary<string, List<string>> Seleccion { get; set; } = new();
        public string Mensaje { get; set; }
        public bool Exito { get; set; }

        public SeleccionProyectosModel(MetricasService metricasService, ConfiguracionService configService)
        {
            _metricasService = metricasService;
            _configService = configService;
        }

        public void OnGet(string mes)
        {
            MesesDisponibles = _metricasService.ObtenerMesesDisponibles();
            if (!MesesDisponibles.Any()) return;

            MesSeleccionado = string.IsNullOrEmpty(mes) ? MesesDisponibles.First() : mes;

            var ruta = _metricasService.ObtenerRutaArchivo(MesSeleccionado);
            if (!System.IO.File.Exists(ruta)) return;

            var proyectos = _metricasService.LeerExcel(ruta);

            // Agrupar proyectos por su propia célula del Excel
            ProyectosPorCelula = proyectos
                .GroupBy(p => p.Celula)
                .ToDictionary(
                    g => g.Key,
                    g => g.Select(p => p.NombreProyecto).Distinct().OrderBy(p => p).ToList()
                );

            TodasLasCelulas = ProyectosPorCelula.Keys.OrderBy(c => c).ToList();
            Seleccion = _configService.CargarSeleccion() ?? new Dictionary<string, List<string>>();
        }

        public IActionResult OnPost(string mes, Dictionary<string, List<string>> seleccionCelulas)
        {
            MesesDisponibles = _metricasService.ObtenerMesesDisponibles();
            MesSeleccionado = string.IsNullOrEmpty(mes) ? MesesDisponibles.FirstOrDefault() : mes;

            var ruta = _metricasService.ObtenerRutaArchivo(MesSeleccionado);
            var proyectos = _metricasService.LeerExcel(ruta);

            ProyectosPorCelula = proyectos
                .GroupBy(p => p.Celula)
                .ToDictionary(
                    g => g.Key,
                    g => g.Select(p => p.NombreProyecto).Distinct().OrderBy(p => p).ToList()
                );

            TodasLasCelulas = ProyectosPorCelula.Keys.OrderBy(c => c).ToList();

            var seleccionFinal = new Dictionary<string, List<string>>();
            foreach (var celula in TodasLasCelulas)
            {
                if (seleccionCelulas != null && seleccionCelulas.ContainsKey(celula))
                    seleccionFinal[celula] = seleccionCelulas[celula];
                else
                    seleccionFinal[celula] = new List<string>();
            }

            _configService.GuardarSeleccion(seleccionFinal);

            Seleccion = seleccionFinal;
            Mensaje = "✅ Selección guardada correctamente.";
            Exito = true;

            return Page();
        }
    }
}