﻿using DeudaTecnicaSonar.Models;

namespace DeudaTecnicaSonar.Services
{
    public class AuthService
    {
        private readonly string _dataPath;

        public AuthService(IWebHostEnvironment env)
        {
            _dataPath = Path.Combine(env.ContentRootPath, "Data");
        }

        public Usuario Autenticar(string usuario, string contrasena)
        {
            var path = Path.Combine(_dataPath, "usuarios.csv");
            if (!File.Exists(path)) return null;

            try
            {
                using var stream = new FileStream(path, FileMode.Open,
                    FileAccess.Read, FileShare.ReadWrite);
                using var reader = new StreamReader(stream);

                string linea;
                bool primeraLinea = true;

                while ((linea = reader.ReadLine()) != null)
                {
                    // Saltar header
                    if (primeraLinea) { primeraLinea = false; continue; }

                    var partes = linea.Split(',');
                    if (partes.Length < 3) continue;

                    if (partes[0].Trim() == usuario && partes[1].Trim() == contrasena)
                    {
                        return new Usuario
                        {
                            NombreUsuario = partes[0].Trim(),
                            Contrasena = partes[1].Trim(),
                            Rol = partes[2].Trim()
                        };
                    }
                }
            }
            catch (IOException)
            {
                return null;
            }

            return null;
        }
    }
}