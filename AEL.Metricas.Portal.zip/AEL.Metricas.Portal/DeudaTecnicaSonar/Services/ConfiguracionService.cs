﻿using DeudaTecnicaSonar.Models;


namespace DeudaTecnicaSonar.Services
{
    public class ConfiguracionService
    {
        private readonly string _dataPath;

        public ConfiguracionService(IWebHostEnvironment env)
        {
            _dataPath = Path.Combine(env.ContentRootPath, "Data");
            Directory.CreateDirectory(_dataPath);
        }

        // ── HELPERS DE ARCHIVO ───────────────────────────────────
        private string[] LeerLineas(string path)
        {
            using var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
            using var reader = new StreamReader(stream);
            var contenido = reader.ReadToEnd();
            return contenido.Split(new[] { "\r\n", "\n" }, StringSplitOptions.RemoveEmptyEntries);
        }

        private void EscribirLineas(string path, string[] lineas)
        {
            using var stream = new FileStream(path, FileMode.Create, FileAccess.Write, FileShare.ReadWrite);
            using var writer = new StreamWriter(stream);
            foreach (var linea in lineas)
                writer.WriteLine(linea);
        }

        private Dictionary<string, string> LeerDict(string path, char separador = ';')
        {
            var lineas = LeerLineas(path);
            if (lineas.Length < 2) return new Dictionary<string, string>();
            var headers = lineas[0].Split(separador);
            var valores = lineas[1].Split(separador);
            var dict = new Dictionary<string, string>();
            for (int i = 0; i < headers.Length && i < valores.Length; i++)
                dict[headers[i].Trim()] = valores[i].Trim();
            return dict;
        }

        // ── PARAMETROS ───────────────────────────────────────────
        public Parametros CargarParametros()
        {
            var path = Path.Combine(_dataPath, "parametros_metricas.csv");
            if (!File.Exists(path)) return new Parametros();

            var dict = LeerDict(path);
            if (!dict.Any()) return new Parametros();

            return new Parametros
            {
                SecurityRating = dict.GetValueOrDefault("security_rating", "A,B,C,D,E"),
                ReliabilityRating = dict.GetValueOrDefault("reliability_rating", "A,B,C,D,E"),
                SqaleRating = dict.GetValueOrDefault("sqale_rating", "A,B,C,D,E"),
                DuplicatedLinesDensity = dict.GetValueOrDefault("duplicated_lines_density", "A,B,C,D,E"),
                CoverageMin = double.TryParse(
                    dict.GetValueOrDefault("coverage_min", "0"),
                    System.Globalization.NumberStyles.Any,
                    System.Globalization.CultureInfo.InvariantCulture,
                    out var cm) ? cm : 0
            };
        }

        public void GuardarParametros(Parametros p)
        {
            var path = Path.Combine(_dataPath, "parametros_metricas.csv");
            EscribirLineas(path, new[]
            {
                "security_rating;reliability_rating;sqale_rating;duplicated_lines_density;coverage_min",
                $"{p.SecurityRating};{p.ReliabilityRating};{p.SqaleRating};{p.DuplicatedLinesDensity};{p.CoverageMin.ToString(System.Globalization.CultureInfo.InvariantCulture)}"
            });
        }

        // ── METAS ────────────────────────────────────────────────
        public Metas CargarMetas()
        {
            var path = Path.Combine(_dataPath, "metas_progreso.csv");
            if (!File.Exists(path)) return new Metas();

            var dict = LeerDict(path);
            if (!dict.Any()) return new Metas();

            double Parse(string key, double def) =>
                double.TryParse(dict.GetValueOrDefault(key, def.ToString()),
                    System.Globalization.NumberStyles.Any,
                    System.Globalization.CultureInfo.InvariantCulture,
                    out var v) ? v : def;

            return new Metas
            {
                MetaSeguridad = Parse("meta_seguridad", 90),
                MetaConfiabilidad = Parse("meta_confiabilidad", 90),
                MetaMantenibilidad = Parse("meta_mantenibilidad", 90),
                MetaCobertura = Parse("meta_cobertura", 70),
                MetaComplejidad = Parse("meta_complejidad", 90)
            };
        }

        public void GuardarMetas(Metas m)
        {
            var path = Path.Combine(_dataPath, "metas_progreso.csv");
            EscribirLineas(path, new[]
            {
                "meta_seguridad;meta_confiabilidad;meta_mantenibilidad;meta_cobertura;meta_complejidad",
                $"{m.MetaSeguridad};{m.MetaConfiabilidad};{m.MetaMantenibilidad};{m.MetaCobertura};{m.MetaComplejidad}"
            });
        }

        // ── CONFIGURACION N/A ────────────────────────────────────
        public ConfiguracionNA CargarConfiguracionNA()
        {
            var path = Path.Combine(_dataPath, "configuracion_na.csv");
            if (!File.Exists(path)) return new ConfiguracionNA();

            var dict = LeerDict(path);
            if (!dict.Any()) return new ConfiguracionNA();

            bool Parse(string key) =>
                bool.TryParse(dict.GetValueOrDefault(key, "false"), out var v) && v;

            return new ConfiguracionNA
            {
                IncluirNaSeguridad = Parse("incluir_na_seguridad"),
                IncluirNaConfiabilidad = Parse("incluir_na_confiabilidad"),
                IncluirNaMantenibilidad = Parse("incluir_na_mantenibilidad"),
                IncluirNaCobertura = Parse("incluir_na_cobertura"),
                IncluirNaComplejidad = Parse("incluir_na_complejidad")
            };
        }

        public void GuardarConfiguracionNA(ConfiguracionNA config)
        {
            var path = Path.Combine(_dataPath, "configuracion_na.csv");
            EscribirLineas(path, new[]
            {
                "incluir_na_seguridad;incluir_na_confiabilidad;incluir_na_mantenibilidad;incluir_na_cobertura;incluir_na_complejidad",
                $"{config.IncluirNaSeguridad};{config.IncluirNaConfiabilidad};{config.IncluirNaMantenibilidad};{config.IncluirNaCobertura};{config.IncluirNaComplejidad}"
            });
        }

        // ── CONFIGURACION METRICAS ───────────────────────────────
        public ConfiguracionMetricas CargarConfiguracionMetricas()
        {
            var path = Path.Combine(_dataPath, "configuracion_metricas.csv");
            if (!File.Exists(path)) return new ConfiguracionMetricas();

            var dict = LeerDict(path);
            if (!dict.Any()) return new ConfiguracionMetricas();

            bool Parse(string key, bool def = false) =>
                bool.TryParse(dict.GetValueOrDefault(key, def.ToString()), out var v) ? v : def;

            return new ConfiguracionMetricas
            {
                SeguridadUsarSeleccionados = Parse("seguridad_usar_seleccionados"),
                ConfiabilidadUsarSeleccionados = Parse("confiabilidad_usar_seleccionados"),
                MantenibilidadUsarSeleccionados = Parse("mantenibilidad_usar_seleccionados"),
                CoberturaUsarSeleccionados = Parse("cobertura_usar_seleccionados", true),
                ComplejidadUsarSeleccionados = Parse("complejidad_usar_seleccionados")
            };
        }

        public void GuardarConfiguracionMetricas(ConfiguracionMetricas config)
        {
            var path = Path.Combine(_dataPath, "configuracion_metricas.csv");
            EscribirLineas(path, new[]
            {
                "seguridad_usar_seleccionados;confiabilidad_usar_seleccionados;mantenibilidad_usar_seleccionados;cobertura_usar_seleccionados;complejidad_usar_seleccionados",
                $"{config.SeguridadUsarSeleccionados};{config.ConfiabilidadUsarSeleccionados};{config.MantenibilidadUsarSeleccionados};{config.CoberturaUsarSeleccionados};{config.ComplejidadUsarSeleccionados}"
            });
        }

        // ── SELECCION DE PROYECTOS ───────────────────────────────
        public Dictionary<string, List<string>> CargarSeleccion()
        {
            var path = Path.Combine(_dataPath, "seleccion_proyectos.csv");
            if (!File.Exists(path)) return null;

            var lineas = LeerLineas(path).Skip(1).ToList();
            if (!lineas.Any()) return null;

            var resultado = new Dictionary<string, List<string>>();
            foreach (var linea in lineas)
            {
                var partes = linea.Split(',');
                if (partes.Length < 2) continue;
                var celula = partes[0].Trim();
                var proyecto = partes[1].Trim();
                if (!resultado.ContainsKey(celula))
                    resultado[celula] = new List<string>();
                resultado[celula].Add(proyecto);
            }

            return resultado.Any() ? resultado : null;
        }

        public void GuardarSeleccion(Dictionary<string, List<string>> seleccion)
        {
            var path = Path.Combine(_dataPath, "seleccion_proyectos.csv");
            var lineas = new List<string> { "Celula,NombreProyecto" };
            foreach (var kvp in seleccion)
                foreach (var proyecto in kvp.Value)
                    lineas.Add($"{kvp.Key},{proyecto}");
            EscribirLineas(path, lineas.ToArray());
        }
    }
}