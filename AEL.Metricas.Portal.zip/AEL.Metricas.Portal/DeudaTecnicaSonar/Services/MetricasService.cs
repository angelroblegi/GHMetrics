﻿using DeudaTecnicaSonar.Models;
using OfficeOpenXml;

namespace DeudaTecnicaSonar.Services
{
    public class MetricasService
    {
        private readonly string _uploadsPath;

        private readonly List<string> _proyectosExcluirCoverage = new()
        {
            "AEL.DebidaDiligencia.FrontEnd:Quality",
            "AEL.NominaElectronica.FrontEnd:Quality"
        };

        public MetricasService(IWebHostEnvironment env)
        {
            _uploadsPath = Path.Combine(env.ContentRootPath, "Uploads");
            Directory.CreateDirectory(_uploadsPath);
            ExcelPackage.License.SetNonCommercialPersonal("DeudaTecnicaSonar");
        }

        // ── ARCHIVOS DISPONIBLES ─────────────────────────────────
        public List<string> ObtenerMesesDisponibles()
        {
            var archivos = Directory.GetFiles(_uploadsPath, "metricas_*.xlsx");
            return archivos
                .Select(f => Path.GetFileNameWithoutExtension(f).Replace("metricas_", ""))
                .OrderByDescending(m => m)  
                .ToList();
        }

        public string ObtenerRutaArchivo(string mes)
        {
            return Path.Combine(_uploadsPath, $"metricas_{mes}.xlsx");
        }

        // ── LEER EXCEL ───────────────────────────────────────────
        public List<MetricaProyecto> LeerExcel(string rutaArchivo)
        {
            var lista = new List<MetricaProyecto>();
            var fi = new FileInfo(rutaArchivo);

            using var package = new ExcelPackage(fi);
            var sheet = package.Workbook.Worksheets[0];

            if (sheet == null || sheet.Dimension == null) return lista;

            // Leer headers
            var headers = new Dictionary<string, int>();
            for (int col = 1; col <= sheet.Dimension.Columns; col++)
            {
                var header = sheet.Cells[1, col].Text.Trim().ToLower();
                if (!string.IsNullOrEmpty(header))
                    headers[header] = col;
            }

            // Leer filas
            for (int row = 2; row <= sheet.Dimension.Rows; row++)
            {
                var proyecto = new MetricaProyecto
                {
                    NombreProyecto = LeerTexto(sheet, row, headers, "nombreproyecto"),
                    Celula = LeerTexto(sheet, row, headers, "celula"),
                    SecurityRating = NormalizarRating(LeerTexto(sheet, row, headers, "security_rating")),
                    ReliabilityRating = NormalizarRating(LeerTexto(sheet, row, headers, "reliability_rating")),
                    SqaleRating = NormalizarRating(LeerTexto(sheet, row, headers, "sqale_rating")),
                    DuplicatedLinesDensity = NormalizarRating(LeerTexto(sheet, row, headers, "duplicated_lines_density")),
                    Coverage = LeerDouble(sheet, row, headers, "coverage"),
                    Bugs = LeerDouble(sheet, row, headers, "bugs"),
                    BugsBlocker = LeerDouble(sheet, row, headers, "bugs_blocker"),
                    BugsCritical = LeerDouble(sheet, row, headers, "bugs_critical"),
                    BugsMajor = LeerDouble(sheet, row, headers, "bugs_major"),
                    BugsMinor = LeerDouble(sheet, row, headers, "bugs_minor"),
                    BugsInfo = LeerDouble(sheet, row, headers, "bugs_info")
                };

                // Leer mes
                if (headers.ContainsKey("mes"))
                {
                    var mesTexto = sheet.Cells[row, headers["mes"]].Text.Trim();
                    if (DateTime.TryParseExact(mesTexto, "yyyy-MM", null,
                        System.Globalization.DateTimeStyles.None, out var fecha))
                        proyecto.Mes = fecha;
                }
                else
                {
                    // Extraer mes del nombre del archivo
                    var nombreArchivo = Path.GetFileNameWithoutExtension(rutaArchivo);
                    var mesStr = nombreArchivo.Replace("metricas_", "");
                    if (DateTime.TryParseExact(mesStr, "yyyy-MM", null,
                        System.Globalization.DateTimeStyles.None, out var fecha))
                        proyecto.Mes = fecha;
                }

                if (!string.IsNullOrEmpty(proyecto.NombreProyecto))
                    lista.Add(proyecto);
            }

            return lista;
        }

        // ── CALCULAR RESUMEN POR CÉLULA ──────────────────────────
        public List<ResumenCelula> CalcularResumen(
            List<MetricaProyecto> proyectos,
            Parametros parametros,
            ConfiguracionNA configNA,
            ConfiguracionMetricas configMetricas,
            Dictionary<string, List<string>> seleccion)
        {
            var celulas = seleccion.Keys.ToList();
            var resultado = new List<ResumenCelula>();

            var umbralSeguridad = parametros.SecurityRating.Split(',').ToList();
            var umbralConfiabilidad = parametros.ReliabilityRating.Split(',').ToList();
            var umbralMantenibilidad = parametros.SqaleRating.Split(',').ToList();
            var umbralComplejidad = parametros.DuplicatedLinesDensity.Split(',').ToList();

            foreach (var celula in celulas)
            {
                // Proyectos de esta célula
                var todosCelula = proyectos.Where(p => p.Celula == celula).ToList();
                var seleccionados = seleccion[celula];

                // Filtrar según configuración de cada métrica
                var dfSeguridad = FiltrarPorMetrica(todosCelula, seleccionados, configMetricas.SeguridadUsarSeleccionados);
                var dfConfiabilidad = FiltrarPorMetrica(todosCelula, seleccionados, configMetricas.ConfiabilidadUsarSeleccionados);
                var dfMantenibilidad = FiltrarPorMetrica(todosCelula, seleccionados, configMetricas.MantenibilidadUsarSeleccionados);
                var dfComplejidad = FiltrarPorMetrica(todosCelula, seleccionados, configMetricas.ComplejidadUsarSeleccionados);
                var dfCobertura = FiltrarPorMetrica(todosCelula, seleccionados, configMetricas.CoberturaUsarSeleccionados)
                    .Where(p => !_proyectosExcluirCoverage.Contains(p.NombreProyecto)).ToList();

                var resumen = new ResumenCelula
                {
                    Celula = celula,
                    Seguridad = CalcularCumplimientoRating(dfSeguridad, p => p.SecurityRating, umbralSeguridad, configNA.IncluirNaSeguridad),
                    Confiabilidad = CalcularCumplimientoRating(dfConfiabilidad, p => p.ReliabilityRating, umbralConfiabilidad, configNA.IncluirNaConfiabilidad),
                    Mantenibilidad = CalcularCumplimientoRating(dfMantenibilidad, p => p.SqaleRating, umbralMantenibilidad, configNA.IncluirNaMantenibilidad),
                    Complejidad = CalcularCumplimientoRating(dfComplejidad, p => p.DuplicatedLinesDensity, umbralComplejidad, configNA.IncluirNaComplejidad),
                    Cobertura = CalcularCumplimientoCobertura(dfCobertura, parametros.CoverageMin, configNA.IncluirNaCobertura),
                    TotalBugs = (int)todosCelula.Sum(p => p.Bugs ?? 0),
                    Critica = (int)todosCelula.Sum(p => p.BugsCritical ?? 0),
                    Alta = (int)todosCelula.Sum(p => p.BugsMajor ?? 0),
                    Media = (int)todosCelula.Sum(p => p.BugsMinor ?? 0),
                    Baja = (int)todosCelula.Sum(p => p.BugsInfo ?? 0)
                };

                resultado.Add(resumen);
            }

            return resultado;
        }

        // ── HELPERS DE CÁLCULO ───────────────────────────────────
        private int CalcularCumplimientoRating(
            List<MetricaProyecto> proyectos,
            Func<MetricaProyecto, string> selector,
            List<string> umbral,
            bool incluirNA)
        {
            if (!proyectos.Any()) return 0;

            List<MetricaProyecto> base_;
            if (incluirNA)
                base_ = proyectos;
            else
                base_ = proyectos.Where(p => selector(p) != null).ToList();

            if (!base_.Any()) return 0;

            var cumplen = base_.Count(p => umbral.Contains(selector(p)));
            return RedondearHaciaArriba(cumplen * 100.0 / base_.Count);
        }

        private int CalcularCumplimientoCobertura(
            List<MetricaProyecto> proyectos,
            double minimo,
            bool incluirNA)
        {
            if (!proyectos.Any()) return 0;

            List<MetricaProyecto> base_;
            if (incluirNA)
                base_ = proyectos;
            else
                base_ = proyectos.Where(p => p.Coverage.HasValue).ToList();

            if (!base_.Any()) return 0;

            var cumplen = base_.Count(p => (p.Coverage ?? 0) >= minimo);
            return RedondearHaciaArriba(cumplen * 100.0 / base_.Count);
        }

        private List<MetricaProyecto> FiltrarPorMetrica(
            List<MetricaProyecto> todos,
            List<string> seleccionados,
            bool usarSeleccionados)
        {
            if (usarSeleccionados && seleccionados.Any())
                return todos.Where(p => seleccionados.Contains(p.NombreProyecto)).ToList();
            return todos;
        }

        private int RedondearHaciaArriba(double valor)
        {
            return (int)(valor + 0.5);
        }

        private string LeerTexto(ExcelWorksheet sheet, int row,
            Dictionary<string, int> headers, string campo)
        {
            if (!headers.ContainsKey(campo)) return null;
            return sheet.Cells[row, headers[campo]].Text.Trim();
        }

        private double? LeerDouble(ExcelWorksheet sheet, int row,
            Dictionary<string, int> headers, string campo)
        {
            if (!headers.ContainsKey(campo)) return null;
            var texto = sheet.Cells[row, headers[campo]].Text.Trim();
            return double.TryParse(texto, out var val) ? val : null;
        }

        private string NormalizarRating(string valor)
        {
            if (string.IsNullOrEmpty(valor)) return null;
            var upper = valor.Trim().ToUpper();
            var validos = new[] { "A", "B", "C", "D", "E" };
            return validos.Contains(upper) ? upper : null;
        }
        public List<MetricaProyecto> LeerTodosLosExcels()
        {
            var lista = new List<MetricaProyecto>();
            var archivos = Directory.GetFiles(_uploadsPath, "metricas_*.xlsx");
            foreach (var archivo in archivos)
            {
                var proyectos = LeerExcel(archivo);
                lista.AddRange(proyectos);
            }
            return lista;
        }
    }
}