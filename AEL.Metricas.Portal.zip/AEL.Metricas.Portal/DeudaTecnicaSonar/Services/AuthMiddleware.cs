﻿namespace DeudaTecnicaSonar.Services
{
    public class AuthMiddleware
    {
        private readonly RequestDelegate _next;

        
        private readonly List<string> _paginasPublicas = new()
        {
            "/index", "/login", "/"
        };

        // Páginas que solo admin puede ver
        private readonly List<string> _paginasAdmin = new()
        {
            "/dashboard", "/configuracion", "/upload", "/seleccionproyectos"
        };

        public AuthMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public async Task InvokeAsync(HttpContext context)
        {
            var path = context.Request.Path.Value?.ToLower() ?? "/";
            var rol = context.Session.GetString("Rol");
            var usuario = context.Session.GetString("Usuario");

            // Si es página pública dejar pasar
            if (_paginasPublicas.Any(p => path == p || path.StartsWith("/css")
                || path.StartsWith("/js") || path.StartsWith("/lib")
                || path.StartsWith("/_")))
            {
                await _next(context);
                return;
            }

            // Si no está logueado redirigir al login
            if (string.IsNullOrEmpty(usuario))
            {
                context.Response.Redirect("/");
                return;
            }

            // Si es usuario normal e intenta acceder a página de admin
            if (rol == "usuario" && _paginasAdmin.Any(p => path.StartsWith(p)))
            {
                context.Response.Redirect("/DetalleCelula");
                return;
            }

            await _next(context);
        }
    }
}