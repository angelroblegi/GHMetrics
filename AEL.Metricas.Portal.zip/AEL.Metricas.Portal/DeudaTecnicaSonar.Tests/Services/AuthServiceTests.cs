using DeudaTecnicaSonar.Services;
using Microsoft.AspNetCore.Hosting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;

namespace DeudaTecnicaSonar.Tests
{
    [TestClass]
    public class AuthServiceTests
    {
        private string _tempPath;
        private AuthService _service;

        [TestInitialize]
        public void Setup()
        {
            _tempPath = Path.Combine(Path.GetTempPath(), Guid.NewGuid().ToString());
            Directory.CreateDirectory(_tempPath);
            Directory.CreateDirectory(Path.Combine(_tempPath, "Data"));

            var mockEnv = new Mock<IWebHostEnvironment>();
            mockEnv.Setup(e => e.ContentRootPath).Returns(_tempPath);
            _service = new AuthService(mockEnv.Object);

            // Crear CSV de usuarios de prueba
            var csvPath = Path.Combine(_tempPath, "Data", "usuarios.csv");
            File.WriteAllLines(csvPath, new[]
            {
                "usuario,contrasena,rol",
                "admin,admin123,admin",
                "juan,juan456,usuario",
                "maria,maria789,usuario"
            });
        }

        [TestCleanup]
        public void Cleanup()
        {
            if (Directory.Exists(_tempPath))
                Directory.Delete(_tempPath, true);
        }

        [TestMethod]
        public void Autenticar_CredencialesCorrectas_RetornaUsuario()
        {
            var resultado = _service.Autenticar("admin", "admin123");

            Assert.IsNotNull(resultado);
            Assert.AreEqual("admin", resultado.NombreUsuario);
            Assert.AreEqual("admin", resultado.Rol);
        }

        [TestMethod]
        public void Autenticar_CredencialesIncorrectas_RetornaNull()
        {
            var resultado = _service.Autenticar("admin", "wrongpassword");
            Assert.IsNull(resultado);
        }

        [TestMethod]
        public void Autenticar_UsuarioNoExiste_RetornaNull()
        {
            var resultado = _service.Autenticar("noexiste", "password");
            Assert.IsNull(resultado);
        }

        [TestMethod]
        public void Autenticar_UsuarioRolUsuario_RetornaRolCorrecto()
        {
            var resultado = _service.Autenticar("juan", "juan456");

            Assert.IsNotNull(resultado);
            Assert.AreEqual("usuario", resultado.Rol);
        }

        [TestMethod]
        public void Autenticar_ArchivoNoExiste_RetornaNull()
        {
            File.Delete(Path.Combine(_tempPath, "Data", "usuarios.csv"));
            var resultado = _service.Autenticar("admin", "admin123");
            Assert.IsNull(resultado);
        }

        [TestMethod]
        public void Autenticar_UsuarioConEspacios_AutenticaCorrectamente()
        {
            var csvPath = Path.Combine(_tempPath, "Data", "usuarios.csv");
            File.WriteAllLines(csvPath, new[]
            {
                "usuario,contrasena,rol",
                " admin , admin123 , admin"
            });

            var resultado = _service.Autenticar("admin", "admin123");
            Assert.IsNotNull(resultado);
        }
    }
}