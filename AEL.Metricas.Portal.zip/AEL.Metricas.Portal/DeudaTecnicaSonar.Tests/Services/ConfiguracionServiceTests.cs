﻿using DeudaTecnicaSonar.Models;
using DeudaTecnicaSonar.Services;
using Microsoft.AspNetCore.Hosting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;

namespace DeudaTecnicaSonar.Tests
{
    [TestClass]
    public class ConfiguracionServiceTests
    {
        private string _tempPath;
        private ConfiguracionService _service;

        [TestInitialize]
        public void Setup()
        {
            _tempPath = Path.Combine(Path.GetTempPath(), Guid.NewGuid().ToString());
            Directory.CreateDirectory(_tempPath);
            Directory.CreateDirectory(Path.Combine(_tempPath, "Data"));

            var mockEnv = new Mock<IWebHostEnvironment>();
            mockEnv.Setup(e => e.ContentRootPath).Returns(_tempPath);
            _service = new ConfiguracionService(mockEnv.Object);
        }

        [TestCleanup]
        public void Cleanup()
        {
            if (Directory.Exists(_tempPath))
                Directory.Delete(_tempPath, true);
        }

        // ── PARAMETROS ───────────────────────────────────────────

        [TestMethod]
        public void CargarParametros_ArchivoNoExiste_RetornaValoresPorDefecto()
        {
            var resultado = _service.CargarParametros();

            Assert.AreEqual("A,B,C,D,E", resultado.SecurityRating);
            Assert.AreEqual("A,B,C,D,E", resultado.ReliabilityRating);
            Assert.AreEqual(0, resultado.CoverageMin);
        }

        [TestMethod]
        public void GuardarYCargarParametros_ValoresMultiples_GuardaCorrectamente()
        {
            var parametros = new Parametros
            {
                SecurityRating = "A,B,C",
                ReliabilityRating = "A",
                SqaleRating = "A,B",
                DuplicatedLinesDensity = "A,B,C,D",
                CoverageMin = 70
            };

            _service.GuardarParametros(parametros);
            var resultado = _service.CargarParametros();

            Assert.AreEqual("A,B,C", resultado.SecurityRating);
            Assert.AreEqual("A", resultado.ReliabilityRating);
            Assert.AreEqual("A,B", resultado.SqaleRating);
            Assert.AreEqual(70, resultado.CoverageMin);
        }

        [TestMethod]
        public void GuardarYCargarParametros_CoverageConDecimal_GuardaCorrectamente()
        {
            var parametros = new Parametros { CoverageMin = 75.5 };
            _service.GuardarParametros(parametros);
            var resultado = _service.CargarParametros();
            Assert.AreEqual(75.5, resultado.CoverageMin);
        }

        // ── METAS ────────────────────────────────────────────────

        [TestMethod]
        public void CargarMetas_ArchivoNoExiste_RetornaValoresPorDefecto()
        {
            var resultado = _service.CargarMetas();

            Assert.AreEqual(90, resultado.MetaSeguridad);
            Assert.AreEqual(90, resultado.MetaConfiabilidad);
            Assert.AreEqual(70, resultado.MetaCobertura);
        }

        [TestMethod]
        public void GuardarYCargarMetas_Correctamente()
        {
            var metas = new Metas
            {
                MetaSeguridad = 85,
                MetaConfiabilidad = 80,
                MetaMantenibilidad = 75,
                MetaCobertura = 60,
                MetaComplejidad = 90
            };

            _service.GuardarMetas(metas);
            var resultado = _service.CargarMetas();

            Assert.AreEqual(85, resultado.MetaSeguridad);
            Assert.AreEqual(80, resultado.MetaConfiabilidad);
            Assert.AreEqual(60, resultado.MetaCobertura);
        }

        // ── CONFIGURACION N/A ────────────────────────────────────

        [TestMethod]
        public void CargarConfiguracionNA_ArchivoNoExiste_RetornaFalsePorDefecto()
        {
            var resultado = _service.CargarConfiguracionNA();

            Assert.IsFalse(resultado.IncluirNaSeguridad);
            Assert.IsFalse(resultado.IncluirNaConfiabilidad);
            Assert.IsFalse(resultado.IncluirNaCobertura);
        }

        [TestMethod]
        public void GuardarYCargarConfiguracionNA_Correctamente()
        {
            var config = new ConfiguracionNA
            {
                IncluirNaSeguridad = true,
                IncluirNaConfiabilidad = false,
                IncluirNaMantenibilidad = true,
                IncluirNaCobertura = true,
                IncluirNaComplejidad = false
            };

            _service.GuardarConfiguracionNA(config);
            var resultado = _service.CargarConfiguracionNA();

            Assert.IsTrue(resultado.IncluirNaSeguridad);
            Assert.IsFalse(resultado.IncluirNaConfiabilidad);
            Assert.IsTrue(resultado.IncluirNaCobertura);
        }

        // ── CONFIGURACION METRICAS ───────────────────────────────

        [TestMethod]
        public void CargarConfiguracionMetricas_ArchivoNoExiste_RetornaValoresPorDefecto()
        {
            var resultado = _service.CargarConfiguracionMetricas();

            Assert.IsFalse(resultado.SeguridadUsarSeleccionados);
            Assert.IsTrue(resultado.CoberturaUsarSeleccionados);
        }

        [TestMethod]
        public void GuardarYCargarConfiguracionMetricas_Correctamente()
        {
            var config = new ConfiguracionMetricas
            {
                SeguridadUsarSeleccionados = true,
                ConfiabilidadUsarSeleccionados = true,
                MantenibilidadUsarSeleccionados = false,
                CoberturaUsarSeleccionados = true,
                ComplejidadUsarSeleccionados = false
            };

            _service.GuardarConfiguracionMetricas(config);
            var resultado = _service.CargarConfiguracionMetricas();

            Assert.IsTrue(resultado.SeguridadUsarSeleccionados);
            Assert.IsTrue(resultado.ConfiabilidadUsarSeleccionados);
            Assert.IsFalse(resultado.MantenibilidadUsarSeleccionados);
        }

        // ── SELECCION ────────────────────────────────────────────

        [TestMethod]
        public void CargarSeleccion_ArchivoNoExiste_RetornaNull()
        {
            var resultado = _service.CargarSeleccion();
            Assert.IsNull(resultado);
        }

        [TestMethod]
        public void GuardarYCargarSeleccion_Correctamente()
        {
            var seleccion = new Dictionary<string, List<string>>
            {
                { "Celula1", new List<string> { "Proyecto1", "Proyecto2" } },
                { "Celula2", new List<string> { "Proyecto3" } }
            };

            _service.GuardarSeleccion(seleccion);
            var resultado = _service.CargarSeleccion();

            Assert.IsNotNull(resultado);
            Assert.AreEqual(2, resultado.Count);
            Assert.IsTrue(resultado["Celula1"].Contains("Proyecto1"));
            Assert.IsTrue(resultado["Celula1"].Contains("Proyecto2"));
            Assert.IsTrue(resultado["Celula2"].Contains("Proyecto3"));
        }

        [TestMethod]
        public void GuardarSeleccion_CelulaVacia_NoSeGuarda()
        {
            var seleccion = new Dictionary<string, List<string>>
            {
                { "Celula1", new List<string>() }
            };

            _service.GuardarSeleccion(seleccion);
            var resultado = _service.CargarSeleccion();

            Assert.IsNull(resultado);
        }
    }
}