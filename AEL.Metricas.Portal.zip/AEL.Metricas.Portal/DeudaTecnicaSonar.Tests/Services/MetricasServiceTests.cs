﻿using DeudaTecnicaSonar.Models;
using DeudaTecnicaSonar.Services;
using Microsoft.AspNetCore.Hosting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;

namespace DeudaTecnicaSonar.Tests.Services
{
    [TestClass]
    public class MetricasServiceTests
    {
        private MetricasService CrearServicio()
        {
            var mockEnv = new Mock<IWebHostEnvironment>();
            mockEnv.Setup(e => e.ContentRootPath)
                   .Returns(Path.GetTempPath());
            return new MetricasService(mockEnv.Object);
        }

        // ── CALCULAR RESUMEN ─────────────────────────────────────

        [TestMethod]
        public void CalcularResumen_ProyectosCumplenSeguridad_RetornaPortaje100()
        {
            var service = CrearServicio();
            var proyectos = new List<MetricaProyecto>
            {
                new() { NombreProyecto = "P1", Celula = "Celula1",
                        SecurityRating = "A", ReliabilityRating = "A",
                        SqaleRating = "A", DuplicatedLinesDensity = "A",
                        Coverage = 80 },
                new() { NombreProyecto = "P2", Celula = "Celula1",
                        SecurityRating = "A", ReliabilityRating = "A",
                        SqaleRating = "A", DuplicatedLinesDensity = "A",
                        Coverage = 90 }
            };

            var parametros = new Parametros
            {
                SecurityRating = "A,B",
                ReliabilityRating = "A,B",
                SqaleRating = "A,B",
                DuplicatedLinesDensity = "A,B",
                CoverageMin = 70
            };

            var seleccion = new Dictionary<string, List<string>>
            {
                { "Celula1", new List<string> { "P1", "P2" } }
            };

            var resultado = service.CalcularResumen(proyectos, parametros,
                new ConfiguracionNA(), new ConfiguracionMetricas(), seleccion);

            Assert.AreEqual(1, resultado.Count);
            Assert.AreEqual(100, resultado[0].Seguridad);
            Assert.AreEqual(100, resultado[0].Confiabilidad);
            Assert.AreEqual(100, resultado[0].Cobertura);
        }

        [TestMethod]
        public void CalcularResumen_MitadProyectosCumplen_Retorna50()
        {
            var service = CrearServicio();
            var proyectos = new List<MetricaProyecto>
            {
                new() { NombreProyecto = "P1", Celula = "Celula1",
                        ReliabilityRating = "A", SqaleRating = "A",
                        DuplicatedLinesDensity = "A", Coverage = 80 },
                new() { NombreProyecto = "P2", Celula = "Celula1",
                        ReliabilityRating = "C", SqaleRating = "C",
                        DuplicatedLinesDensity = "C", Coverage = 10 }
            };

            var parametros = new Parametros
            {
                SecurityRating = "A,B",
                ReliabilityRating = "A,B",
                SqaleRating = "A,B",
                DuplicatedLinesDensity = "A,B",
                CoverageMin = 70
            };

            var seleccion = new Dictionary<string, List<string>>
            {
                { "Celula1", new List<string> { "P1", "P2" } }
            };

            var resultado = service.CalcularResumen(proyectos, parametros,
                new ConfiguracionNA(), new ConfiguracionMetricas(), seleccion);

            Assert.AreEqual(50, resultado[0].Confiabilidad);
            Assert.AreEqual(50, resultado[0].Cobertura);
        }

        [TestMethod]
        public void CalcularResumen_SinProyectos_RetornaListaVacia()
        {
            var service = CrearServicio();
            var resultado = service.CalcularResumen(
                new List<MetricaProyecto>(),
                new Parametros(),
                new ConfiguracionNA(),
                new ConfiguracionMetricas(),
                new Dictionary<string, List<string>> { { "Celula1", new() } });

            Assert.AreEqual(0, resultado[0].Seguridad);
        }

        [TestMethod]
        public void CalcularResumen_ProyectosConNA_ExcluyeNADelCalculo()
        {
            var service = CrearServicio();
            var proyectos = new List<MetricaProyecto>
            {
                new() { NombreProyecto = "P1", Celula = "Celula1",
                        ReliabilityRating = "A" },
                new() { NombreProyecto = "P2", Celula = "Celula1",
                        ReliabilityRating = null } // N/A
            };

            var parametros = new Parametros { ReliabilityRating = "A,B" };
            var seleccion = new Dictionary<string, List<string>>
            {
                { "Celula1", new List<string> { "P1", "P2" } }
            };

            // Con excluir N/A → solo P1 cuenta → 100%
            var configNA = new ConfiguracionNA { IncluirNaConfiabilidad = false };
            var resultado = service.CalcularResumen(proyectos, parametros,
                configNA, new ConfiguracionMetricas(), seleccion);

            Assert.AreEqual(100, resultado[0].Confiabilidad);
        }

        [TestMethod]
        public void CalcularResumen_ProyectosConNA_IncluyeNAComoNoCumple()
        {
            var service = CrearServicio();
            var proyectos = new List<MetricaProyecto>
            {
                new() { NombreProyecto = "P1", Celula = "Celula1",
                        ReliabilityRating = "A" },
                new() { NombreProyecto = "P2", Celula = "Celula1",
                        ReliabilityRating = null } // N/A cuenta como no cumple
            };

            var parametros = new Parametros { ReliabilityRating = "A,B" };
            var seleccion = new Dictionary<string, List<string>>
            {
                { "Celula1", new List<string> { "P1", "P2" } }
            };

            // Con incluir N/A → P1 cumple, P2 no → 50%
            var configNA = new ConfiguracionNA { IncluirNaConfiabilidad = true };
            var resultado = service.CalcularResumen(proyectos, parametros,
                configNA, new ConfiguracionMetricas(), seleccion);

            Assert.AreEqual(50, resultado[0].Confiabilidad);
        }

        [TestMethod]
        public void CalcularResumen_UsarSeleccionados_FiltrasCorrectamente()
        {
            var service = CrearServicio();
            var proyectos = new List<MetricaProyecto>
            {
                new() { NombreProyecto = "P1", Celula = "Celula1",
                        ReliabilityRating = "A" },
                new() { NombreProyecto = "P2", Celula = "Celula1",
                        ReliabilityRating = "D" } // No cumple pero no está seleccionado
            };

            var parametros = new Parametros { ReliabilityRating = "A,B" };
            var seleccion = new Dictionary<string, List<string>>
            {
                { "Celula1", new List<string> { "P1" } } // Solo P1 seleccionado
            };

            var configMetricas = new ConfiguracionMetricas
            {
                ConfiabilidadUsarSeleccionados = true
            };

            var resultado = service.CalcularResumen(proyectos, parametros,
                new ConfiguracionNA(), configMetricas, seleccion);

            Assert.AreEqual(100, resultado[0].Confiabilidad);
        }

        [TestMethod]
        public void CalcularResumen_Bugs_SumaCorrectamente()
        {
            var service = CrearServicio();
            var proyectos = new List<MetricaProyecto>
            {
                new() { NombreProyecto = "P1", Celula = "Celula1",
                        Bugs = 5, BugsCritical = 2, BugsMajor = 2, BugsMinor = 1 },
                new() { NombreProyecto = "P2", Celula = "Celula1",
                        Bugs = 3, BugsCritical = 1, BugsMajor = 1, BugsMinor = 1 }
            };

            var seleccion = new Dictionary<string, List<string>>
            {
                { "Celula1", new List<string> { "P1", "P2" } }
            };

            var resultado = service.CalcularResumen(proyectos, new Parametros(),
                new ConfiguracionNA(), new ConfiguracionMetricas(), seleccion);

            Assert.AreEqual(8, resultado[0].TotalBugs);
            Assert.AreEqual(3, resultado[0].Critica);
        }

        [TestMethod]
        public void CalcularResumen_RedondeoHaciaArriba_Correcto()
        {
            var service = CrearServicio();
            // 2 de 3 proyectos cumplen = 66.66% → debe redondear a 67%
            var proyectos = new List<MetricaProyecto>
            {
                new() { NombreProyecto = "P1", Celula = "C1", ReliabilityRating = "A" },
                new() { NombreProyecto = "P2", Celula = "C1", ReliabilityRating = "A" },
                new() { NombreProyecto = "P3", Celula = "C1", ReliabilityRating = "D" }
            };

            var parametros = new Parametros { ReliabilityRating = "A,B" };
            var seleccion = new Dictionary<string, List<string>>
            {
                { "C1", new List<string> { "P1", "P2", "P3" } }
            };

            var resultado = service.CalcularResumen(proyectos, parametros,
                new ConfiguracionNA(), new ConfiguracionMetricas(), seleccion);

            Assert.AreEqual(67, resultado[0].Confiabilidad);
        }
    }
}